# POPCity Extra

Mod complementario para el servidor **POPCity** de Arma Reforger. Añade contenido nuevo **sin modificar** los mods de POPCity: todo se apoya en ellos como dependencias (herencia de prefabs, subclases, `modded class` y configs propias).

- Prefijo de clases y archivos: `PCX_`
- Dependencias: Arma Reforger, POPCity, POPCityProps, POPCityStructures, POPCityVehicles (y, a través de POPCity, SmokeableSmokes).

> POPCity es obra de R3X0 ("No utilizar mods POPCity sin permiso de R3X0"). Este repositorio solo contiene el contenido propio de POPCity Extra; para usarlo hace falta tener los mods de POPCity.

## Contenido

### Estanco (`Prefabs/Structures/Estanco/PCX_Estanco.et`)
Edificio de estanco típico español (7 × 9 m, dos plantas, azotea mediterránea) con interior usable: mostrador con vitrina, estanterías de tabaco, expositor, trastienda.
- 4 LODs, colisiones por material (gamemats vanilla), oclusores.
- Puerta de cristal que se abre (`PCX_EstancoPuerta.et`, hereda de `Door_Base`).
- 6 luces de techo que se encienden de noche (`PCX_EstancoLuz.et`).
- Rótulo "TABACOS" y banderola de la "T" luminosos.
- Incluye la máquina de tabaco como entidad hija.

### Máquina de tabaco (`Prefabs/Structures/Estanco/PCX_MaquinaTabaco.et`)
Vende las 6 cajetillas de SmokeableSmokes (120 cada una) usando el **sistema de tiendas de POPCity**: catálogo, cobro por el backend y entrega al inventario los hace POPCity.
- Config: `Configs/Economy/Stores/PCX/PCX_MaquinaTabaco.conf`
- Script: `Scripts/Game/PCX/Stores/PCX_PublicStoreProviderComponent.c` (subclase de `ARL_ObjectStoreProviderComponent` abierta a todas las facciones).
- Requiere el backend de POPCity: en un Workbench local sin conexión la acción no aparece.

### Taquillas personales (`Prefabs/Structures/Taquillas/PCX_Taquilla.et`)
Taquilla metálica donde cada personaje tiene su propio espacio, el mismo en todas las taquillas del mapa, y que se conserva entre reinicios.
- Acción "Abrir mi taquilla": el servidor crea un almacén temporal (`PCX_TaquillaAlmacen.et`), mete lo guardado y abre el inventario nativo.
- Guardado en JSON en el servidor: `$profile:PCX/Taquillas/pj_<characterId>.json`.
- Nadie puede sacar objetos de la taquilla de otro.
- Scripts: `Scripts/Game/PCX/Taquillas/`.

### Atraco al prostíbulo
Atraco en dos fases integrado con los sistemas de robo de POPCity.
1. **Encargado** (`Prefabs/Characters/Prostibulo/PCX_EncargadoProstibulo.et`): hay que encañonarle sin parar (apuntado de POPCity, a menos de 4 m). Levanta las manos, avisa a la policía y deja antecedentes en el PDA.
2. **Caja fuerte** (`Prefabs/Props/Prostibulo/PCX_CajaFuerteProstibulo.et`): solo el atracador puede forzarla con un minijuego de rueda de combinación (3 números, pistas de "cerca/lejos", fallos y tiempo limitados). La combinación solo existe en el servidor.
3. **Botín**: la caja se llena con fajos de dinero negro de POPCity (entre 12.000 y 18.000 € por defecto) y se abre el inventario al atracador. A los 5 min se cierra y se vacía. Después hay enfriamiento.
- Todo se ajusta en los atributos de `PCX_AtracoProstibuloComponent` (caja fuerte): mínimo de policías, tiempos, fallos, botín, enfriamientos.
- Encargado y caja se emparejan por el identificador `prostibulo`.
- Scripts: `Scripts/Game/PCX/Prostibulo/`. UI: `UI/layouts/PCX/PCX_RuedaCombinacion.layout`.
- Requiere el backend de POPCity (personaje activado); en un Workbench local sin conexión el atraco no arranca.

## Fuentes
`Source/Estanco/PCX_Estanco.blend` contiene el estanco, la puerta y la máquina. Dentro del .blend hay textos con el código que genera los modelos (`pcx_build.py`, `reforger_helpers.py`, `pak_reader.py`).

## Instalación para desarrollo
1. Clonar en `Documents/My Games/ArmaReforgerWorkbench/addons/POPCity Extra`.
2. Abrir el proyecto en Workbench (con los mods de POPCity descargados).
3. Hacer *Register and Import* de los `.fbx` y `.tif` de `Assets/` si no se generan solos.
