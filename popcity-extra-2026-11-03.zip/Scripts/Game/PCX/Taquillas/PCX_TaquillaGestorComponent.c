// POPCity Extra - Taquillas personales.
// Va en el prefab del almacén personal (PCX_TaquillaAlmacen.et), la "caja" invisible que
// aparece al abrir la taquilla y se abre con el inventario nativo del juego.
// - Solo su dueño puede sacar cosas.
// - Avisa al servidor de que ha habido cambios para guardar el JSON.

class PCX_TaquillaGestorComponentClass : ScriptedInventoryStorageManagerComponentClass
{
}

class PCX_TaquillaGestorComponent : ScriptedInventoryStorageManagerComponent
{
	[RplProp()]
	protected int m_iPropietario = -1;	// playerId del dueño (replicado para la UI del cliente)

	protected bool m_bAbierto;			// solo servidor: false mientras se restaura o se cierra
	protected bool m_bCambios;			// solo servidor: hay algo sin guardar

	//------------------------------------------------------------------------------------------------
	void PCX_Configurar(int playerId)
	{
		m_iPropietario = playerId;
		Replication.BumpMe();
	}

	//------------------------------------------------------------------------------------------------
	int PCX_GetPropietario()
	{
		return m_iPropietario;
	}

	//------------------------------------------------------------------------------------------------
	void PCX_SetAbierto(bool abierto)
	{
		m_bAbierto = abierto;
	}

	//------------------------------------------------------------------------------------------------
	//! Devuelve si hubo cambios desde la última llamada y limpia la marca.
	bool PCX_ConsumirCambios()
	{
		bool cambios = m_bCambios;
		m_bCambios = false;
		return cambios;
	}

	//------------------------------------------------------------------------------------------------
	override protected void OnItemAdded(BaseInventoryStorageComponent storageOwner, IEntity item)
	{
		super.OnItemAdded(storageOwner, item);
		if (m_bAbierto)
			m_bCambios = true;
	}

	//------------------------------------------------------------------------------------------------
	override protected void OnItemRemoved(BaseInventoryStorageComponent storageOwner, IEntity item)
	{
		super.OnItemRemoved(storageOwner, item);
		if (m_bAbierto)
			m_bCambios = true;
	}

	//------------------------------------------------------------------------------------------------
	//! Nadie más que el dueño puede sacar objetos. Mientras se restaura o se cierra, nadie.
	override protected bool ShouldForbidRemoveByInstigator(InventoryStorageManagerComponent instigatorManager, BaseInventoryStorageComponent fromStorage, IEntity item)
	{
		if (instigatorManager == this)
			return false;

		if (Replication.IsServer() && !m_bAbierto)
			return true;

		if (!instigatorManager)
			return true;

		int playerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(instigatorManager.GetOwner());
		return playerId != m_iPropietario;
	}
}
