// POPCity Extra - Taller POP MOTORS.
// Acción "Abrir/Cerrar portón" o "Subir/Bajar elevador": alterna la PCX_ParteMovilComponent del
// prefab. El nombre cambia según el estado. El cambio lo hace el servidor.

class PCX_ParteMovilAction : ScriptedUserAction
{
	[Attribute("Abrir", UIWidgets.EditBox, "Texto cuando está abajo / cerrado")]
	protected string m_sTextoSubir;

	[Attribute("Cerrar", UIWidgets.EditBox, "Texto cuando está arriba / abierto")]
	protected string m_sTextoBajar;

	protected PCX_ParteMovilComponent m_Parte;

	//------------------------------------------------------------------------------------------------
	override void Init(IEntity pOwnerEntity, GenericComponent pManagerComponent)
	{
		m_Parte = PCX_ParteMovilComponent.DesdeEntidad(pOwnerEntity);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return m_Parte != null;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!Replication.IsServer() || !m_Parte)
			return;

		m_Parte.Alternar_S(pUserEntity);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		if (!m_Parte)
			return false;

		if (m_Parte.EstaArriba())
			outName = m_sTextoBajar;
		else
			outName = m_sTextoSubir;
		return true;
	}
}
