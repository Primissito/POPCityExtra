// POPCity Extra - Taller POP MOTORS.
// Parte móvil genérica: desplaza el PRIMER HIJO del prefab entre su posición de reposo y
// reposo + m_vRecorrido (coordenadas locales del padre). La usan el portón corredero vertical
// (hoja) y el elevador de coches (carros + brazos).
// El servidor decide el estado (RplProp) y cada máquina anima la pieza localmente, así todos
// la ven moverse igual y quien entra tarde la ve en su sitio.

[ComponentEditorProps(category: "GameScripted/PCX", description: "Mueve el primer hijo entre reposo y reposo + recorrido")]
class PCX_ParteMovilComponentClass : ScriptComponentClass
{
}

class PCX_ParteMovilComponent : ScriptComponent
{
	[Attribute("0 3.85 0", UIWidgets.EditBox, "Recorrido de la pieza móvil en coordenadas locales del padre (m)")]
	protected vector m_vRecorrido;

	[Attribute("0.5", UIWidgets.EditBox, "Velocidad (m/s)", "0.05 5 0.05")]
	protected float m_fVelocidad;

	// true = hacia el final del recorrido (abierto / arriba)
	[RplProp(onRplName: "OnRplEstado")]
	protected bool m_bArriba;

	protected IEntity m_Pieza;
	protected vector m_aReposo[4];
	protected float m_fPos;            // 0 = reposo, 1 = final del recorrido
	protected float m_fUltimoTick = -1;
	protected bool m_bTicando;
	protected bool m_bListo;

	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		// Los hijos del prefab todavía pueden no estar enlazados: se buscan un poco después.
		GetGame().GetCallqueue().CallLater(Preparar, 100, false);
	}

	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		GetGame().GetCallqueue().Remove(Preparar);
		GetGame().GetCallqueue().Remove(Tick);
		super.OnDelete(owner);
	}

	//------------------------------------------------------------------------------------------------
	protected void Preparar()
	{
		IEntity owner = GetOwner();
		if (!owner)
			return;

		m_Pieza = owner.GetChildren();
		if (!m_Pieza)
		{
			Print(string.Format("[PCX] ParteMovil: %1 no tiene hijo que mover", owner), LogLevel.WARNING);
			return;
		}

		m_Pieza.GetLocalTransform(m_aReposo);
		m_bListo = true;

		// Estado inicial (o el que haya llegado por replicación al entrar tarde): sin animación.
		m_fPos = 0;
		if (m_bArriba)
			m_fPos = 1;
		AplicarPosicion();
	}

	//------------------------------------------------------------------------------------------------
	// Solo servidor
	void Alternar_S(IEntity usuario)
	{
		SetArriba_S(!m_bArriba, usuario);
	}

	//------------------------------------------------------------------------------------------------
	// Solo servidor
	void SetArriba_S(bool arriba, IEntity usuario = null)
	{
		if (!Replication.IsServer() || arriba == m_bArriba)
			return;

		if (!PuedeCambiar_S(arriba, usuario))
			return;

		m_bArriba = arriba;
		Replication.BumpMe();
		OnRplEstado(); // el servidor no recibe su propio callback
	}

	//------------------------------------------------------------------------------------------------
	// Para las clases hijas (el elevador busca aquí el coche antes de subir).
	protected bool PuedeCambiar_S(bool arriba, IEntity usuario)
	{
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected void OnRplEstado()
	{
		if (!m_bListo)
			return; // Preparar() colocará la pieza en su sitio

		ArrancarTick();
	}

	//------------------------------------------------------------------------------------------------
	protected void ArrancarTick()
	{
		if (m_bTicando)
			return;

		m_bTicando = true;
		m_fUltimoTick = -1;
		GetGame().GetCallqueue().CallLater(Tick, 0, true);
	}

	//------------------------------------------------------------------------------------------------
	protected void Tick()
	{
		IEntity owner = GetOwner();
		if (!owner || !owner.GetWorld())
			return;

		float ahora = owner.GetWorld().GetWorldTime();
		float dt = 0;
		if (m_fUltimoTick >= 0)
			dt = (ahora - m_fUltimoTick) * 0.001;
		m_fUltimoTick = ahora;

		float largo = m_vRecorrido.Length();
		float paso = 1;
		if (largo > 0.001)
			paso = m_fVelocidad * dt / largo;

		float objetivo = 0;
		if (m_bArriba)
			objetivo = 1;

		if (m_fPos < objetivo)
			m_fPos = Math.Min(m_fPos + paso, objetivo);
		else if (m_fPos > objetivo)
			m_fPos = Math.Max(m_fPos - paso, objetivo);

		AplicarPosicion();

		if (m_fPos == objetivo)
		{
			GetGame().GetCallqueue().Remove(Tick);
			m_bTicando = false;
			OnLlegada();
		}
	}

	//------------------------------------------------------------------------------------------------
	protected void AplicarPosicion()
	{
		if (!m_Pieza)
			return;

		vector mat[4];
		mat[0] = m_aReposo[0];
		mat[1] = m_aReposo[1];
		mat[2] = m_aReposo[2];
		mat[3] = m_aReposo[3] + m_vRecorrido * m_fPos;
		m_Pieza.SetLocalTransform(mat);
		m_Pieza.Update(); // VERIFICAR que la colisión de la pieza sigue al mallado al moverla

		OnPosicion(m_fPos);
	}

	//------------------------------------------------------------------------------------------------
	// Ganchos para clases hijas
	protected void OnPosicion(float pos)
	{
	}

	protected void OnLlegada()
	{
	}

	//------------------------------------------------------------------------------------------------
	bool EstaArriba()
	{
		return m_bArriba;
	}

	//------------------------------------------------------------------------------------------------
	bool EnMovimiento()
	{
		return m_bTicando;
	}

	//------------------------------------------------------------------------------------------------
	static PCX_ParteMovilComponent DesdeEntidad(IEntity ent)
	{
		if (!ent)
			return null;
		return PCX_ParteMovilComponent.Cast(ent.FindComponent(PCX_ParteMovilComponent));
	}
}
