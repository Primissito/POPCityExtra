// POPCity Extra - Taller POP MOTORS.
// Guarda en cada vehículo el color de carrocería elegido en el taller y lo replica a todos los
// jugadores (también a los que llegan tarde o se acercan después). Va en el gestor de daños del
// vehículo porque todos los coches lo tienen y ya está replicado.
// El color dura mientras exista el vehículo (al guardarlo en el garaje vuelve el de fábrica).

modded class SCR_VehicleDamageManagerComponent
{
	[RplProp(onRplName: "PCX_OnRplPintura")]
	protected int m_iPCXPintura;

	//------------------------------------------------------------------------------------------------
	int PCX_GetPintura()
	{
		return m_iPCXPintura;
	}

	//------------------------------------------------------------------------------------------------
	// Solo servidor
	void PCX_SetPintura_S(int indice)
	{
		if (!Replication.IsServer() || !PCX_PinturaColores.Valido(indice))
			return;

		m_iPCXPintura = indice;
		Replication.BumpMe();
		PCX_OnRplPintura(); // el servidor no recibe su propio callback
	}

	//------------------------------------------------------------------------------------------------
	protected void PCX_OnRplPintura()
	{
		// Un poco después: al entrar en red las piezas hijas (puertas, capó) pueden no estar aún.
		GetGame().GetCallqueue().Remove(PCX_AplicarPintura);
		GetGame().GetCallqueue().CallLater(PCX_AplicarPintura, 200, false);
	}

	//------------------------------------------------------------------------------------------------
	protected void PCX_AplicarPintura()
	{
		IEntity vehiculo = GetOwner();
		if (!vehiculo)
			return;

		int encontrados = PCX_PinturaColores.Aplicar(vehiculo, m_iPCXPintura);
		Print(string.Format("[PCX] Pintura: %1 -> %2 (%3 materiales)", vehiculo,
			PCX_PinturaColores.Nombre(m_iPCXPintura), encontrados), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	static SCR_VehicleDamageManagerComponent PCX_DesdeVehiculo(IEntity vehiculo)
	{
		if (!vehiculo)
			return null;
		return SCR_VehicleDamageManagerComponent.Cast(vehiculo.FindComponent(SCR_VehicleDamageManagerComponent));
	}
}
