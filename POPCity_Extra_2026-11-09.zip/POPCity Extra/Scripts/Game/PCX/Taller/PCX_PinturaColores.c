// POPCity Extra - Taller POP MOTORS.
// Paleta de pintura de carrocería y lógica para pintar un vehículo.
// El color se aplica cambiando (remap) los materiales de la malla del vehículo y de sus piezas
// hijas (puertas, capó...). Índice 0 = color original de fábrica.
// (La pintura de llantas se quitó en la v4.5: daba demasiados problemas.)

class PCX_PinturaColores
{
	static const int ORIGINAL = 0;

	// Nombres que se muestran (índice 0 = original)
	static const ref array<string> NOMBRES = {
		"Original", "Blanco", "Plata", "Grafito", "Negro", "Rojo", "Burdeos", "Naranja", "Amarillo",
		"Verde lima", "Verde oscuro", "Celeste", "Azul", "Azul marino", "Morado", "Rosa", "Marrón"
	};

	// Color de muestra para el menú (sRGB, 0xRRGGBB)
	static const ref array<int> MUESTRAS = {
		0x3A3F45, 0xF0F0F0, 0xAAAEB2, 0x46484C, 0x0C0C0E, 0xBE1414, 0x640A19, 0xEB6E0A, 0xF5C80A,
		0x78C81E, 0x0F4623, 0x46AAE6, 0x1446BE, 0x0A1946, 0x641E96, 0xEB5AA0, 0x5F3C23
	};

	// Materiales de pintura (Assets/Vehicles/PCX_Pintura/Data)
	static const ref array<ResourceName> MATERIALES = {
		"",
		"{0BB174D4B4A7FD0D}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Blanco.emat",
		"{86FA7B4AE0BF5D79}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Plata.emat",
		"{957CD153778461D3}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Grafito.emat",
		"{852F1EF231E8E40B}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Negro.emat",
		"{8E278521EEAE2AD1}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Rojo.emat",
		"{DDFF5C9AA1D13C47}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Burdeos.emat",
		"{5CA89C74E5FE6582}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Naranja.emat",
		"{660C1227DBD568CB}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Amarillo.emat",
		"{9443BF94F438303B}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_VerdeLima.emat",
		"{7B4CDD8C37AB2C75}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_VerdeOscuro.emat",
		"{C9B7FCD8F17B03FA}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Celeste.emat",
		"{2D887D41CED55DD5}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Azul.emat",
		"{3B7AD8CAEF6A2E87}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_AzulMarino.emat",
		"{C93989EC901BEF96}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Morado.emat",
		"{617BCF8B75C98A5A}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Rosa.emat",
		"{B49C1B8DC22DCDB3}Assets/Vehicles/PCX_Pintura/Data/PCX_Pintura_Marron.emat"
	};

	//------------------------------------------------------------------------------------------------
	// Un material es carrocería si su nombre contiene alguna de estas palabras...
	static const ref array<string> CLAVES_CARROCERIA = {
		"paint", "carroceria", "carrocería", "body", "exterior", "livery", "chassis", "chasis", "pintura"
	};

	// ...y ninguna de estas (cristales, luces, interior, ruedas, logos...).
	static const ref array<string> CLAVES_EXCLUIDAS = {
		"glass", "cristal", "light", "lamp", "luz", "led", "emissive", "interior", "seat", "asiento",
		"chrome", "cromo", "_rim", "rim_", "llanta", "tire", "tyre", "rubber", "goma", "wheel", "decal", "logo",
		"badge", "plate", "matricula", "mirror", "espejo", "engine", "motor", "brake", "freno", "carbon",
		"_on", "lens", "screen", "pantalla", "dash", "gauge", "window", "windshield", "windscreen", "ventana", "parabrisas"
	};

	// Trozos de nombre que contienen una palabra clave sin ser carrocería: se quitan antes de buscar
	// (p. ej. el Dodge Charger "Hellacious": TODOS sus materiales empiezan por DodgeDodge_WidebodyChargerF9...).
	static const ref array<string> FALSOS_POSITIVOS = {
		"widebody"
	};

	// Materiales concretos que NUNCA se pintan aunque su nombre parezca de carrocería.
	static const ref array<string> MATERIALES_EXCLUIDOS_EXTRA = {
		// Javelin (Core): car_paint2 solo está en las 4 ruedas
		"car_paint2"
	};

	// Materiales concretos de coches cuyos nombres no dicen nada (M000, M001...).
	// Formato: parte del nombre del material, tal y como sale en el log "[PCX] Pintura: materiales de ...".
	static const ref array<string> MATERIALES_EXTRA = {
		// Bugatti Divo "Los Sicarios" (librea roja y amarilla)
		"BugatiLosSicarios_SpainRed",
		"BugatiLosSicarios_SpainYellow",
		// Pagani Emindero
		"PaganiEmindero_Orange",
		// Ford F-150 Raptor (F150_M000 = carrocería, textura bodyblack)
		"F150_M000",
		// Mercedes 190 (Mercedes190_M000 = carrocería, rvmat car2; los de policía están bloqueados aparte)
		"Mercedes190_M000",
		// Mercedes G63 (G63_M000 = carrocería, textura bodyblack, rvmat metallic)
		"G63_M000",
		// Ford Mustang (PlanetArmaMuscleCars; textura UPT_Paint)
		"MustangMI_1210060001_018"
	};

	// Vehículos de policía y emergencias: NO se pueden pintar en el taller.
	// Prefabs sacados de los catálogos de POPCity (Policia_Normal, Policia_Aereo, Medico_Normal,
	// Medico_Aereo). Se compara con el prefab del coche y con todos sus padres, así que las
	// variantes que hereden de estos también quedan bloqueadas.
	static const ref array<string> PREFABS_EMERGENCIA = {
		// Policía
		"MercedesVitoCNP/Vito_CNP.et",
		"KoenigseggAgeraCNP/Agera_CNP.et",
		"ToyotaGT86CNP/GT86_CNP.et",
		"JeepCherokeeCNP/Cherokee_CNP.et",
		"CupraFormentor/Cupra_Formentor_Policia.et",
		"POP_Camion_Grua/POP_Camion_Grua.et",
		"UH1H_Police.et",
		// Médicos
		"Medico/Mercedes_Sprinter_2016_SAMUR.et",
		"Medico/Audi_RS4_SAMUR.et",
		"CG_Stretcher_Civil.et",
		"Corbillard/POP_corbillard_c_noir.et",
		"UH1H_Medical.et"
	};

	// Por si se añaden coches nuevos de emergencias: si la ruta del prefab (o de un padre)
	// contiene alguna de estas palabras, tampoco se puede pintar.
	static const ref array<string> CLAVES_EMERGENCIA = {
		"polic", "cnp", "guardiacivil", "guardia_civil", "patrulla", "samur", "ambulan", "medico",
		"medical", "sanitar", "_ems", "ems_", "sprinterems", "bomber", "firetruck", "emergenc", "corbillard"
	};

	// Componentes que solo llevan los vehículos de emergencias (si la clase no existe se ignora).
	static const ref array<string> COMPONENTES_EMERGENCIA = {
		"ARL_SirenaPoliciaComponent"
	};

	//------------------------------------------------------------------------------------------------
	static int Cantidad()
	{
		return NOMBRES.Count();
	}

	//------------------------------------------------------------------------------------------------
	static string Nombre(int indice)
	{
		if (!Valido(indice))
			return "";
		return NOMBRES[indice];
	}

	//------------------------------------------------------------------------------------------------
	static Color ColorMuestra(int indice)
	{
		int c = MUESTRAS[indice];
		return Color.FromRGBA((c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF, 255);
	}

	//------------------------------------------------------------------------------------------------
	static bool Valido(int indice)
	{
		return indice >= 0 && indice < Cantidad();
	}

	//------------------------------------------------------------------------------------------------
	static bool EsCarroceria(string material)
	{
		string m = material;
		m.ToLower();

		foreach (string excluido : MATERIALES_EXCLUIDOS_EXTRA)
		{
			string x = excluido;
			x.ToLower();
			if (!x.IsEmpty() && m.Contains(x))
				return false;
		}

		foreach (string extra : MATERIALES_EXTRA)
		{
			string e = extra;
			e.ToLower();
			if (!e.IsEmpty() && m.Contains(e))
				return true;
		}

		foreach (string falso : FALSOS_POSITIVOS)
		{
			m.Replace(falso, "");
		}

		foreach (string no : CLAVES_EXCLUIDAS)
		{
			if (m.Contains(no))
				return false;
		}

		foreach (string si : CLAVES_CARROCERIA)
		{
			if (m.Contains(si))
				return true;
		}
		return false;
	}

	//------------------------------------------------------------------------------------------------
	// true si el vehículo es de policía o emergencias (no se puede pintar).
	static bool EsVehiculoEmergencia(IEntity vehiculo)
	{
		if (!vehiculo)
			return false;

		foreach (string nombreComp : COMPONENTES_EMERGENCIA)
		{
			typename tipo = nombreComp.ToType();
			if (tipo && vehiculo.FindComponent(tipo))
				return true;
		}

		EntityPrefabData datos = vehiculo.GetPrefabData();
		if (!datos)
			return false;

		if (EsRutaEmergencia(datos.GetPrefabName()))
			return true;

		// Subir por la herencia del prefab (variantes, colores...).
		BaseContainer prefab = datos.GetPrefab();
		int vueltas = 0;
		while (prefab && vueltas < 16)
		{
			if (EsRutaEmergencia(prefab.GetResourceName()))
				return true;
			prefab = prefab.GetAncestor();
			vueltas++;
		}
		return false;
	}

	//------------------------------------------------------------------------------------------------
	protected static bool EsRutaEmergencia(string ruta)
	{
		if (ruta.IsEmpty())
			return false;

		string r = ruta;
		r.ToLower();
		r.Replace("\\", "/");

		foreach (string prefab : PREFABS_EMERGENCIA)
		{
			string p = prefab;
			p.ToLower();
			if (r.Contains(p))
				return true;
		}

		foreach (string clave : CLAVES_EMERGENCIA)
		{
			if (r.Contains(clave))
				return true;
		}
		return false;
	}

	//------------------------------------------------------------------------------------------------
	// Aplica el color (en esta máquina) al vehículo y a todas sus piezas hijas.
	// Devuelve cuántos materiales de carrocería se han encontrado.
	static int Aplicar(IEntity vehiculo, int color)
	{
		if (!vehiculo)
			return 0;
		if (!Valido(color))
			color = ORIGINAL;

		int encontrados = 0;
		AplicarEnEntidad(vehiculo, color, encontrados);

		if (encontrados == 0 && color != ORIGINAL)
			ListarMateriales(vehiculo);
		return encontrados;
	}

	//------------------------------------------------------------------------------------------------
	protected static void AplicarEnEntidad(IEntity ent, int color, inout int encontrados)
	{
		VObject malla = ent.GetVObject();
		if (malla)
		{
			// Remap que ya trae el prefab (p. ej. los coches hechos sobre el Humvee ocultan su
			// carrocería con Invisible.emat). Hay que conservarlo: SetObject lo sustituye entero.
			map<string, string> remapPrefab = new map<string, string>();
			LeerRemapPrefab(ent, remapPrefab);

			string materiales[256];
			int n = malla.GetMaterials(materiales);
			string remap;
			int propios = 0;
			for (int i = 0; i < n; i++)
			{
				string asignado = "";
				remapPrefab.Find(Clave(materiales[i]), asignado);

				// Lo que se ve es el material asignado por el prefab (si lo hay).
				string visible = materiales[i];
				if (!asignado.IsEmpty())
					visible = FilePath.StripExtension(FilePath.StripPath(asignado));

				if (EsCarroceria(visible))
				{
					propios++;
					if (color != ORIGINAL)
					{
						remap += string.Format("$remap '%1' '%2';", materiales[i], MATERIALES[color]);
						continue;
					}
				}

				if (!asignado.IsEmpty())
					remap += string.Format("$remap '%1' '%2';", materiales[i], asignado);
			}
			encontrados += propios;

			// Solo se toca la malla si tiene algo pintable; en Original queda solo el remap del prefab.
			if (propios > 0)
				ent.SetObject(malla, remap);
		}

		IEntity hijo = ent.GetChildren();
		while (hijo)
		{
			// Los ocupantes (personajes) también cuelgan del vehículo: no se pintan.
			if (!ChimeraCharacter.Cast(hijo))
				AplicarEnEntidad(hijo, color, encontrados);
			hijo = hijo.GetSibling();
		}
	}

	//------------------------------------------------------------------------------------------------
	// Nombre de material sin ruta y en minúsculas (el prefab a veces lo guarda con ruta y a veces sin ella).
	protected static string Clave(string material)
	{
		string c = FilePath.StripPath(material);
		c.ToLower();
		return c;
	}

	//------------------------------------------------------------------------------------------------
	// Lee la lista "Materials" del MeshObject del prefab de la entidad: material original -> emat asignado.
	protected static void LeerRemapPrefab(IEntity ent, map<string, string> remap)
	{
		EntityPrefabData datos = ent.GetPrefabData();
		if (!datos)
			return;

		BaseContainer prefab = datos.GetPrefab();
		if (!prefab)
			return;

		BaseContainerList componentes = prefab.GetObjectArray("components");
		if (!componentes)
			return;

		for (int c = 0; c < componentes.Count(); c++)
		{
			BaseContainer comp = componentes.Get(c);
			if (!comp || comp.GetClassName() != "MeshObject")
				continue;

			BaseContainerList lista = comp.GetObjectArray("Materials");
			if (!lista)
				return;

			for (int m = 0; m < lista.Count(); m++)
			{
				BaseContainer mat = lista.Get(m);
				if (!mat)
					continue;

				ResourceName origen = "";
				ResourceName destino = "";
				mat.Get("SourceMaterial", origen);
				mat.Get("AssignedMaterial", destino);
				if (!origen.IsEmpty() && !destino.IsEmpty())
					remap.Set(Clave(origen), destino);
			}
			return;
		}
	}

	//------------------------------------------------------------------------------------------------
	// Para configurar coches nuevos: escribe en el log los materiales que tiene el vehículo.
	static void ListarMateriales(IEntity vehiculo)
	{
		string nombre = vehiculo.ToString();
		EntityPrefabData datos = vehiculo.GetPrefabData();
		if (datos)
			nombre = datos.GetPrefabName();

		Print(string.Format("[PCX] Pintura: materiales de %1 (ninguno reconocido como carrocería; añádelos a PCX_PinturaColores.MATERIALES_EXTRA):", nombre), LogLevel.WARNING);
		ListarEnEntidad(vehiculo, 0);
	}

	//------------------------------------------------------------------------------------------------
	protected static void ListarEnEntidad(IEntity ent, int nivel)
	{
		if (nivel > 4)
			return;

		VObject malla = ent.GetVObject();
		if (malla)
		{
			map<string, string> remapPrefab = new map<string, string>();
			LeerRemapPrefab(ent, remapPrefab);

			string materiales[256];
			int n = malla.GetMaterials(materiales);
			for (int i = 0; i < n; i++)
			{
				string asignado = "";
				remapPrefab.Find(Clave(materiales[i]), asignado);
				if (asignado.IsEmpty())
					Print(string.Format("[PCX] Pintura:   %1", materiales[i]), LogLevel.WARNING);
				else
					Print(string.Format("[PCX] Pintura:   %1 -> %2", materiales[i], FilePath.StripPath(asignado)), LogLevel.WARNING);
			}
		}

		IEntity hijo = ent.GetChildren();
		while (hijo)
		{
			if (!ChimeraCharacter.Cast(hijo))
				ListarEnEntidad(hijo, nivel + 1);
			hijo = hijo.GetSibling();
		}
	}
}
