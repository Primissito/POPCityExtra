// POPCity Extra - Taller POP MOTORS.
// Elevador de coches de dos columnas. Hereda la animación de PCX_ParteMovilComponent (el hijo
// del prefab son los carros + brazos) y además engancha el vehículo que haya entre las columnas:
//  - Al pulsar "Subir" el servidor busca un vehículo parado en la zona y replica su RplId y su
//    posición relativa al elevador.
//  - Cada máquina saca el vehículo de la simulación (queda como colisión estática, se puede
//    trabajar debajo), lo hace hijo del elevador y lo sube con los brazos.
//  - Al volver abajo del todo lo suelta y le devuelve la física.
// Mismo patrón que la grúa de POP_Logistica (AddChild + ChangeSimulationState + SetLocalTransform).

[ComponentEditorProps(category: "GameScripted/PCX", description: "Elevador de coches: sube el vehículo que hay entre las columnas")]
class PCX_ElevadorComponentClass : PCX_ParteMovilComponentClass
{
}

class PCX_ElevadorComponent : PCX_ParteMovilComponent
{
	[Attribute("-1.3 -0.6 -2.6", UIWidgets.EditBox, "Zona donde debe estar el origen del vehículo: esquina mínima (local)")]
	protected vector m_vZonaMin;

	[Attribute("1.3 1.5 2.6", UIWidgets.EditBox, "Zona donde debe estar el origen del vehículo: esquina máxima (local)")]
	protected vector m_vZonaMax;

	[Attribute("0.15", UIWidgets.EditBox, "Metros que suben los brazos antes de tocar el coche")]
	protected float m_fHolguraContacto;

	[Attribute("1.0", UIWidgets.EditBox, "Velocidad máxima del vehículo para poder subirlo (m/s)")]
	protected float m_fVelocidadMaxima;

	[Attribute("1", UIWidgets.CheckBox, "Solo los mecánicos de POPCity pueden pintar coches aquí (desmarcar para probar en Workbench sin backend)")]
	protected bool m_bSoloMecanicos;

	[RplProp(onRplName: "OnRplVehiculo")]
	protected RplId m_VehiculoId;

	// Transformación del vehículo relativa al elevador en el momento de engancharlo
	[RplProp(onRplName: "OnRplVehiculo")]
	protected vector m_vVehLocal0;
	[RplProp(onRplName: "OnRplVehiculo")]
	protected vector m_vVehLocal1;
	[RplProp(onRplName: "OnRplVehiculo")]
	protected vector m_vVehLocal2;
	[RplProp(onRplName: "OnRplVehiculo")]
	protected vector m_vVehLocal3;

	protected IEntity m_Vehiculo;
	protected bool m_bEnganchado;

	protected ref array<IEntity> m_aCandidatos = {};

	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		m_VehiculoId = RplId.Invalid();
		super.OnPostInit(owner);
	}

	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		Soltar();
		super.OnDelete(owner);
	}

	//------------------------------------------------------------------------------------------------
	override protected void Preparar()
	{
		super.Preparar();
		OnRplVehiculo(); // quien entra tarde con un coche ya subido
	}

	//------------------------------------------------------------------------------------------------
	override protected bool PuedeCambiar_S(bool arriba, IEntity usuario)
	{
		if (!arriba || m_VehiculoId.IsValid())
			return true;

		// Solo se coge coche si los brazos están abajo del todo.
		if (m_fPos > 0.001)
			return true;

		IEntity vehiculo = BuscarVehiculo();
		if (!vehiculo)
		{
			Print("[PCX] Elevador: sube sin vehículo", LogLevel.NORMAL);
			return true;
		}

		vector mundoElev[4];
		vector mundoVeh[4];
		vector local[4];
		GetOwner().GetWorldTransform(mundoElev);
		vehiculo.GetWorldTransform(mundoVeh);
		Math3D.MatrixInvMultiply4(mundoElev, mundoVeh, local);

		m_vVehLocal0 = local[0];
		m_vVehLocal1 = local[1];
		m_vVehLocal2 = local[2];
		m_vVehLocal3 = local[3];
		m_VehiculoId = Replication.FindItemId(vehiculo);
		if (!m_VehiculoId.IsValid())
		{
			Print(string.Format("[PCX] Elevador: %1 no está replicado, no se puede subir", vehiculo), LogLevel.WARNING);
			return true;
		}

		Print(string.Format("[PCX] Elevador: enganchado %1", vehiculo), LogLevel.NORMAL);
		Replication.BumpMe();
		OnRplVehiculo();
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected IEntity BuscarVehiculo()
	{
		IEntity owner = GetOwner();
		m_aCandidatos.Clear();
		owner.GetWorld().QueryEntitiesBySphere(owner.GetOrigin(), 4.5, AnadirCandidato, null, EQueryEntitiesFlags.DYNAMIC);

		IEntity mejor;
		float mejorDist = 1000;
		foreach (IEntity e : m_aCandidatos)
		{
			vector p = owner.CoordToLocal(e.GetOrigin());
			if (p[0] < m_vZonaMin[0] || p[0] > m_vZonaMax[0])
				continue;
			if (p[1] < m_vZonaMin[1] || p[1] > m_vZonaMax[1])
				continue;
			if (p[2] < m_vZonaMin[2] || p[2] > m_vZonaMax[2])
				continue;

			Physics fisica = e.GetPhysics();
			if (fisica && fisica.GetVelocity().Length() > m_fVelocidadMaxima)
				continue;

			float d = p[0] * p[0] + p[2] * p[2];
			if (d < mejorDist)
			{
				mejorDist = d;
				mejor = e;
			}
		}
		return mejor;
	}

	//------------------------------------------------------------------------------------------------
	protected bool AnadirCandidato(IEntity e)
	{
		if (e && Vehicle.Cast(e) && !e.GetParent() && m_aCandidatos.Find(e) == -1)
			m_aCandidatos.Insert(e);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected void OnRplVehiculo()
	{
		if (!m_bListo)
			return;

		if (!m_VehiculoId.IsValid())
		{
			Soltar();
			return;
		}

		if (!m_Vehiculo)
			m_Vehiculo = IEntity.Cast(Replication.FindItem(m_VehiculoId));

		if (m_Vehiculo && !m_bEnganchado)
			Enganchar();
	}

	//------------------------------------------------------------------------------------------------
	protected void Enganchar()
	{
		Physics fisica = m_Vehiculo.GetPhysics();
		if (fisica)
		{
			fisica.SetVelocity(vector.Zero);
			fisica.SetAngularVelocity(vector.Zero);
			// En el mundo de colisión pero sin simular: no cae y se puede trabajar debajo.
			// VERIFICAR: si el coche tiembla o no se mueve en los clientes, probar SimulationState.NONE (lo que usa la grúa).
			fisica.ChangeSimulationState(SimulationState.COLLISION);
		}

		GetOwner().AddChild(m_Vehiculo, -1, EAddChildFlags.AUTO_TRANSFORM | EAddChildFlags.RECALC_LOCAL_TRANSFORM);
		m_bEnganchado = true;
		ColocarVehiculo();
	}

	//------------------------------------------------------------------------------------------------
	protected void Soltar()
	{
		if (!m_bEnganchado)
		{
			m_Vehiculo = null;
			return;
		}

		m_bEnganchado = false;
		if (!m_Vehiculo)
			return;

		// Dejarlo exactamente donde estaba al engancharlo (abajo) antes de devolverle la física.
		ColocarVehiculoAltura(0);

		if (m_Vehiculo.GetParent() == GetOwner())
			GetOwner().RemoveChild(m_Vehiculo, true);

		Physics fisica = m_Vehiculo.GetPhysics();
		if (fisica)
		{
			fisica.ChangeSimulationState(SimulationState.SIMULATION);
			fisica.SetActive(ActiveState.ACTIVE);
			fisica.SetVelocity(vector.Zero);
			fisica.SetAngularVelocity(vector.Zero);
		}

		Print(string.Format("[PCX] Elevador: soltado %1", m_Vehiculo), LogLevel.NORMAL);
		m_Vehiculo = null;
	}

	//------------------------------------------------------------------------------------------------
	protected void ColocarVehiculo()
	{
		float subida = m_fPos * m_vRecorrido.Length() - m_fHolguraContacto;
		ColocarVehiculoAltura(Math.Max(subida, 0));
	}

	//------------------------------------------------------------------------------------------------
	protected void ColocarVehiculoAltura(float altura)
	{
		if (!m_Vehiculo || m_Vehiculo.GetParent() != GetOwner())
			return;

		vector mat[4];
		mat[0] = m_vVehLocal0;
		mat[1] = m_vVehLocal1;
		mat[2] = m_vVehLocal2;
		mat[3] = m_vVehLocal3 + vector.Up * altura;
		m_Vehiculo.SetLocalTransform(mat);
		m_Vehiculo.Update();
	}

	//------------------------------------------------------------------------------------------------
	override protected void OnPosicion(float pos)
	{
		if (m_bEnganchado)
			ColocarVehiculo();
	}

	//------------------------------------------------------------------------------------------------
	override protected void OnLlegada()
	{
		if (m_fPos > 0.001)
			return;

		// Abajo del todo: soltar el coche.
		if (Replication.IsServer() && m_VehiculoId.IsValid())
		{
			m_VehiculoId = RplId.Invalid();
			Replication.BumpMe();
		}
		Soltar();
	}

	//------------------------------------------------------------------------------------------------
	bool TieneVehiculo()
	{
		return m_bEnganchado;
	}

	//------------------------------------------------------------------------------------------------
	IEntity GetVehiculo()
	{
		if (m_bEnganchado)
			return m_Vehiculo;
		return null;
	}

	//------------------------------------------------------------------------------------------------
	bool SoloMecanicos()
	{
		return m_bSoloMecanicos;
	}
}
