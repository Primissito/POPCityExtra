// POPCity Extra - Taller POP MOTORS.
// Acción "Pintar coche" del elevador y menú de la paleta (solo cliente). El menú se abre igual
// que la rueda de la caja fuerte: diálogo configurable vacío + nuestro layout encima.

class PCX_PinturaAction : ScriptedUserAction
{
	protected PCX_ElevadorComponent m_Elevador;
	protected IEntity m_UltimoVehiculo;
	protected bool m_bUltimoEmergencia;

	//------------------------------------------------------------------------------------------------
	override void Init(IEntity pOwnerEntity, GenericComponent pManagerComponent)
	{
		m_Elevador = PCX_ElevadorComponent.Cast(pOwnerEntity.FindComponent(PCX_ElevadorComponent));
	}

	//------------------------------------------------------------------------------------------------
	override bool HasLocalEffectOnlyScript()
	{
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return m_Elevador && m_Elevador.TieneVehiculo() && !PCX_PinturaDialog.EstaAbierto();
	}

	//------------------------------------------------------------------------------------------------
	// Los coches de policía y emergencias muestran la acción en gris con el motivo.
	override bool CanBePerformedScript(IEntity user)
	{
		IEntity vehiculo;
		if (m_Elevador)
			vehiculo = m_Elevador.GetVehiculo();

		if (vehiculo != m_UltimoVehiculo)
		{
			m_UltimoVehiculo = vehiculo;
			m_bUltimoEmergencia = PCX_PinturaColores.EsVehiculoEmergencia(vehiculo);
		}

		if (m_bUltimoEmergencia)
		{
			SetCannotPerformReason("Vehículo de emergencias");
			return false;
		}
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity || pUserEntity != SCR_PlayerController.GetLocalControlledEntity())
			return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerController());
		if (!rpl || !pc)
			return;

		PCX_PinturaDialog.Preparar(rpl.Id());
		pc.PCX_PinturaPedir(rpl.Id());
	}
}

class PCX_PinturaDialogHost : SCR_ConfigurableDialogUi
{
	override void OnMenuFocusLost()
	{
		super.OnMenuFocusLost();
		PCX_PinturaDialog.Cerrar();
	}
}

class PCX_PinturaDialog : ScriptedWidgetEventHandler
{
	protected static const ResourceName RUTA_LAYOUT = "UI/layouts/PCX/PCX_Pintura.layout";
	protected static const int CASILLAS = 16; // Color1..Color16 en el layout (+ Color0 = Original)

	protected static ref PCX_PinturaDialog s_Instancia;
	protected static RplId s_Elevador;

	protected Widget m_Root;
	protected MenuBase m_Menu;
	protected ref PCX_PinturaDialogHost m_Host;
	protected int m_iColor;
	protected bool m_bEsperando;

	//------------------------------------------------------------------------------------------------
	static bool EstaAbierto()
	{
		return s_Instancia != null;
	}

	//------------------------------------------------------------------------------------------------
	static void Preparar(RplId elevador)
	{
		s_Elevador = elevador;
	}

	//------------------------------------------------------------------------------------------------
	static void Recibir(int respuesta, int color, string texto)
	{
		if (respuesta == PCX_ERespuestaPintura.RECHAZADO)
		{
			Cerrar();
			ARL_NativeMessageManager.ShowWarning(texto);
			return;
		}

		if (respuesta == PCX_ERespuestaPintura.ABRIR)
		{
			Cerrar();
			s_Instancia = new PCX_PinturaDialog();
			s_Instancia.Abrir(color);
			return;
		}

		if (respuesta == PCX_ERespuestaPintura.PINTADO)
		{
			SCR_UISoundEntity.SoundEvent(SCR_SoundEvent.TASK_SUCCEED);
			ARL_NativeMessageManager.ShowSuccess(texto);
			if (s_Instancia)
				s_Instancia.Actualizar(color);
		}
	}

	//------------------------------------------------------------------------------------------------
	static void Cerrar()
	{
		PCX_PinturaDialog vieja = s_Instancia;
		s_Instancia = null;
		if (vieja)
			vieja.Liberar();
	}

	//------------------------------------------------------------------------------------------------
	protected void Abrir(int color)
	{
		m_Menu = GetGame().GetMenuManager().OpenDialog(ChimeraMenuPreset.ConfigurableDialog, DialogPriority.INFORMATIVE, 0, true);
		SCR_ConfigurableDialogUiProxy proxy = SCR_ConfigurableDialogUiProxy.Cast(m_Menu);
		if (!proxy)
		{
			Cerrar();
			return;
		}

		m_Host = new PCX_PinturaDialogHost();
		proxy.Init(m_Host);
		m_Root = GetGame().GetWorkspace().CreateWidgets(RUTA_LAYOUT, m_Menu.GetRootWidget());
		if (!m_Root)
		{
			Print("[PCX] Pintura: no se encuentra el layout " + RUTA_LAYOUT, LogLevel.ERROR);
			Cerrar();
			return;
		}

		m_Root.AddHandler(this);
		int cantidad = PCX_PinturaColores.Cantidad();
		for (int i = 0; i <= CASILLAS; i++)
		{
			Widget boton = m_Root.FindAnyWidget("Color" + i.ToString());
			if (!boton)
				continue;

			bool visible = i < cantidad;
			boton.SetVisible(visible);
			if (!visible)
				continue;
			boton.AddHandler(this);

			// Color0 (Original) mantiene su fondo gris.
			Widget muestra = m_Root.FindAnyWidget("Color" + i.ToString() + "Muestra");
			if (muestra && i > 0)
				muestra.SetColor(PCX_PinturaColores.ColorMuestra(i));

			TextWidget nombre = TextWidget.Cast(m_Root.FindAnyWidget("Color" + i.ToString() + "Nombre"));
			if (nombre)
				nombre.SetText(PCX_PinturaColores.Nombre(i));
		}

		Widget salir = m_Root.FindAnyWidget("Salir");
		if (salir)
			salir.AddHandler(this);

		GetGame().GetInputManager().AddActionListener(UIConstants.MENU_ACTION_BACK, EActionTrigger.DOWN, Cerrar);
		GetGame().GetCallqueue().CallLater(Tick, 200, true);

		m_iColor = color;
		Marcar();
	}

	//------------------------------------------------------------------------------------------------
	protected void Liberar()
	{
		GetGame().GetCallqueue().Remove(Tick);
		GetGame().GetCallqueue().Remove(Desbloquear);
		GetGame().GetInputManager().RemoveActionListener(UIConstants.MENU_ACTION_BACK, EActionTrigger.DOWN, Cerrar);
		if (m_Root)
		{
			m_Root.RemoveFromHierarchy();
			m_Root = null;
		}
		if (m_Menu)
		{
			GetGame().GetMenuManager().CloseMenu(m_Menu);
			m_Menu = null;
		}
	}

	//------------------------------------------------------------------------------------------------
	protected void Actualizar(int color)
	{
		m_iColor = color;
		m_bEsperando = false;
		Marcar();
	}

	//------------------------------------------------------------------------------------------------
	// Resalta el color actual.
	protected void Marcar()
	{
		if (!m_Root)
			return;

		for (int i = 0; i <= CASILLAS; i++)
		{
			Widget borde = m_Root.FindAnyWidget("Color" + i.ToString() + "Borde");
			if (!borde)
				continue;
			if (i == m_iColor)
				borde.SetColor(Color.FromRGBA(245, 200, 10, 255));
			else
				borde.SetColor(Color.FromRGBA(40, 44, 50, 255));
		}

		TextWidget estado = TextWidget.Cast(m_Root.FindAnyWidget("Estado"));
		if (estado)
			estado.SetText("Color actual: " + PCX_PinturaColores.Nombre(m_iColor));
	}

	//------------------------------------------------------------------------------------------------
	protected void Tick()
	{
		if (!m_Root)
			return;

		// Se cierra si el jugador muere o se aleja.
		IEntity cuerpo = SCR_PlayerController.GetLocalControlledEntity();
		CharacterControllerComponent control;
		if (cuerpo)
			control = CharacterControllerComponent.Cast(cuerpo.FindComponent(CharacterControllerComponent));
		if (!control || control.IsDead() || control.IsUnconscious())
		{
			Cerrar();
			return;
		}

		PCX_ElevadorComponent elevador = PCX_PinturaServicio.ResolverElevador(s_Elevador);
		if (!elevador || !elevador.TieneVehiculo() || vector.Distance(cuerpo.GetOrigin(), elevador.GetOwner().GetOrigin()) > 8)
		{
			Cerrar();
			return;
		}
		GetGame().GetInputManager().ActivateContext("MenuContext");
	}

	//------------------------------------------------------------------------------------------------
	protected void Pintar(int indice)
	{
		if (m_bEsperando || indice == m_iColor)
			return;

		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc)
			return;

		m_bEsperando = true;
		SCR_UISoundEntity.SoundEvent(SCR_SoundEvent.CLICK);
		pc.PCX_PinturaAplicar(s_Elevador, indice);

		// Por si el servidor no contesta (antispam), no dejar el menú bloqueado.
		GetGame().GetCallqueue().Remove(Desbloquear);
		GetGame().GetCallqueue().CallLater(Desbloquear, 1500, false);
	}

	//------------------------------------------------------------------------------------------------
	protected void Desbloquear()
	{
		m_bEsperando = false;
	}

	//------------------------------------------------------------------------------------------------
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!w || !m_Root)
			return false;

		string nombre = w.GetName();
		if (nombre == "Salir")
		{
			Cerrar();
			return true;
		}

		if (nombre.StartsWith("Color"))
		{
			int indice = nombre.Substring(5, nombre.Length() - 5).ToInt(-1);
			if (PCX_PinturaColores.Valido(indice))
			{
				Pintar(indice);
				return true;
			}
		}
		return false;
	}
}
