// POPCity Extra - Taller POP MOTORS.
// RPCs de la pintura de coches en el elevador (mismo patrón que el atraco: el cliente pide, el
// servidor comprueba permisos y distancia y responde al dueño).

enum PCX_ERespuestaPintura
{
	RECHAZADO,
	ABRIR,
	PINTADO
}

class PCX_PinturaServicio
{
	protected static const float DISTANCIA_MAX = 8.0;

	//------------------------------------------------------------------------------------------------
	static PCX_ElevadorComponent ResolverElevador(RplId id)
	{
		if (!id.IsValid())
			return null;

		Managed objeto = Replication.FindItem(id);
		RplComponent rpl = RplComponent.Cast(objeto);
		IEntity entidad;
		if (rpl)
			entidad = rpl.GetEntity();
		else
			entidad = IEntity.Cast(objeto);
		if (!entidad)
			return null;
		return PCX_ElevadorComponent.Cast(entidad.FindComponent(PCX_ElevadorComponent));
	}

	//------------------------------------------------------------------------------------------------
	// Solo servidor. Devuelve el gestor del coche si se puede pintar; si no, responde al jugador.
	protected static SCR_VehicleDamageManagerComponent Validar(SCR_PlayerController pc, RplId elevadorId)
	{
		PCX_ElevadorComponent elevador = ResolverElevador(elevadorId);
		IEntity cuerpo = pc.GetControlledEntity();
		if (!elevador || !cuerpo)
			return null;

		if (vector.Distance(cuerpo.GetOrigin(), elevador.GetOwner().GetOrigin()) > DISTANCIA_MAX)
			return null;

		int jugador = pc.GetPlayerId();
		if (elevador.SoloMecanicos() && !ARL_MechanicRepairRewards.IsMechanic(jugador))
		{
			pc.PCX_PinturaRespuesta(PCX_ERespuestaPintura.RECHAZADO, -1, "Solo los mecánicos pueden pintar coches.");
			return null;
		}

		IEntity vehiculo = elevador.GetVehiculo();
		if (!vehiculo)
		{
			pc.PCX_PinturaRespuesta(PCX_ERespuestaPintura.RECHAZADO, -1, "Sube primero un coche al elevador.");
			return null;
		}

		if (PCX_PinturaColores.EsVehiculoEmergencia(vehiculo))
		{
			pc.PCX_PinturaRespuesta(PCX_ERespuestaPintura.RECHAZADO, -1, "Los vehículos de policía y emergencias no se pueden pintar.");
			return null;
		}

		SCR_VehicleDamageManagerComponent gestor = SCR_VehicleDamageManagerComponent.PCX_DesdeVehiculo(vehiculo);
		if (!gestor)
		{
			pc.PCX_PinturaRespuesta(PCX_ERespuestaPintura.RECHAZADO, -1, "Este vehículo no se puede pintar.");
			return null;
		}
		return gestor;
	}

	//------------------------------------------------------------------------------------------------
	static void ServidorAbrir(SCR_PlayerController pc, RplId elevadorId)
	{
		SCR_VehicleDamageManagerComponent gestor = Validar(pc, elevadorId);
		if (gestor)
			pc.PCX_PinturaRespuesta(PCX_ERespuestaPintura.ABRIR, gestor.PCX_GetPintura(), "");
	}

	//------------------------------------------------------------------------------------------------
	static void ServidorAplicar(SCR_PlayerController pc, RplId elevadorId, int indice)
	{
		if (!PCX_PinturaColores.Valido(indice))
			return;

		SCR_VehicleDamageManagerComponent gestor = Validar(pc, elevadorId);
		if (!gestor)
			return;

		gestor.PCX_SetPintura_S(indice);
		string color = PCX_PinturaColores.Nombre(indice);
		Print(string.Format("[PCX] Pintura: jugador %1 pinta %2 de %3", pc.GetPlayerId(), gestor.GetOwner(), color), LogLevel.NORMAL);

		string texto = string.Format("Coche pintado: %1.", color);
		if (indice == PCX_PinturaColores.ORIGINAL)
			texto = "Coche devuelto a su color original.";
		pc.PCX_PinturaRespuesta(PCX_ERespuestaPintura.PINTADO, gestor.PCX_GetPintura(), texto);
	}
}

modded class SCR_PlayerController
{
	protected float m_fPCXPinturaSiguiente;

	//------------------------------------------------------------------------------------------------
	// Cliente -> servidor
	//------------------------------------------------------------------------------------------------
	void PCX_PinturaPedir(RplId elevador)
	{
		Rpc(RpcAsk_PCX_PinturaPedir, elevador);
	}

	//------------------------------------------------------------------------------------------------
	void PCX_PinturaAplicar(RplId elevador, int indice)
	{
		Rpc(RpcAsk_PCX_PinturaAplicar, elevador, indice);
	}

	//------------------------------------------------------------------------------------------------
	protected bool PCX_PinturaAntispam()
	{
		float ahora = GetGame().GetWorld().GetWorldTime();
		if (ahora < m_fPCXPinturaSiguiente)
			return false;
		m_fPCXPinturaSiguiente = ahora + 400;
		return true;
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	protected void RpcAsk_PCX_PinturaPedir(RplId elevador)
	{
		if (!Replication.IsServer() || !PCX_PinturaAntispam())
			return;
		PCX_PinturaServicio.ServidorAbrir(this, elevador);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	protected void RpcAsk_PCX_PinturaAplicar(RplId elevador, int indice)
	{
		if (!Replication.IsServer() || !PCX_PinturaAntispam())
			return;
		PCX_PinturaServicio.ServidorAplicar(this, elevador, indice);
	}

	//------------------------------------------------------------------------------------------------
	// Servidor -> dueño
	//------------------------------------------------------------------------------------------------
	void PCX_PinturaRespuesta(int respuesta, int color, string texto)
	{
		Rpc(RpcDo_PCX_PinturaRespuesta, respuesta, color, texto);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PCX_PinturaRespuesta(int respuesta, int color, string texto)
	{
		PCX_PinturaDialog.Recibir(respuesta, color, texto);
	}
}
