# POPCity Extra

Mod complementario para el servidor **POPCity** de Arma Reforger. Añade contenido nuevo **sin modificar** los mods de POPCity: todo se apoya en ellos como dependencias (herencia de prefabs, subclases y configs propias).

- Prefijo de clases y archivos: `PCX_`
- Dependencias: Arma Reforger, POPCity, POPCityProps, POPCityStructures, POPCityVehicles (y, a través de POPCity, SmokeableSmokes).

> POPCity es obra de R3X0 ("No utilizar mods POPCity sin permiso de R3X0"). Este repositorio solo contiene el contenido propio de POPCity Extra; para usarlo hace falta tener los mods de POPCity.

## Contenido

### Estanco (`Prefabs/Structures/Estanco/PCX_Estanco.et`)
Edificio de estanco típico español (7 × 9 m, dos plantas, azotea mediterránea) con interior usable: mostrador con vitrina, estanterías de tabaco, expositor, trastienda.
- 4 LODs, colisiones por material (gamemats vanilla), oclusores.
- Puerta de cristal que se abre (`PCX_EstancoPuerta.et`, hereda de `Door_Base`).
- 6 luces de techo que se encienden de noche (`PCX_EstancoLuz.et`).
- Rótulo "TABACOS" y banderola de la "T" luminosos.
- Incluye la máquina de tabaco como entidad hija.

### Máquina de tabaco (`Prefabs/Structures/Estanco/PCX_MaquinaTabaco.et`)
Vende las 6 cajetillas de SmokeableSmokes (120 cada una) usando el **sistema de tiendas de POPCity**: catálogo, cobro por el backend y entrega al inventario los hace POPCity.
- Config: `Configs/Economy/Stores/PCX/PCX_MaquinaTabaco.conf`
- Script: `Scripts/Game/PCX/Stores/PCX_PublicStoreProviderComponent.c` (subclase de `ARL_ObjectStoreProviderComponent` abierta a todas las facciones).
- Requiere el backend de POPCity: en un Workbench local sin conexión la acción no aparece.

## Fuentes
`Source/Estanco/PCX_Estanco.blend` contiene el estanco, la puerta y la máquina. Dentro del .blend hay textos con el código que genera los modelos (`pcx_build.py`, `reforger_helpers.py`, `pak_reader.py`).

## Instalación para desarrollo
1. Clonar en `Documents/My Games/ArmaReforgerWorkbench/addons/POPCity Extra`.
2. Abrir el proyecto en Workbench (con los mods de POPCity descargados).
3. Hacer *Register and Import* de los `.fbx` y `.tif` de `Assets/` si no se generan solos.
