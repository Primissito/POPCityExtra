"""Utilidades para preparar assets de Arma Reforger en Blender (probado en 5.2 LTS; pensado para 4.2+).

INSTALACIÓN DESDE EL CONECTOR (una vez por sesión de Blender):
envía con execute_blender_code este bloque, pegando el contenido de este archivo
como texto del datablock (así queda guardado dentro del .blend):

    import bpy, sys, types
    SRC = <contenido de este archivo como string>
    t = bpy.data.texts.get("reforger_helpers.py") or bpy.data.texts.new("reforger_helpers.py")
    t.clear(); t.write(SRC)
    m = types.ModuleType("reforger_helpers")
    exec(t.as_string(), m.__dict__)
    sys.modules["reforger_helpers"] = m
    result = {"ok": True, "funciones": [n for n in dir(m) if not n.startswith("_")]}

Si Blender se reinicia y el .blend ya contiene el texto, basta con:

    import bpy, sys, types
    m = types.ModuleType("reforger_helpers")
    exec(bpy.data.texts["reforger_helpers.py"].as_string(), m.__dict__)
    sys.modules["reforger_helpers"] = m

Uso en llamadas posteriores:  import reforger_helpers as helpers

Nota: este archivo no debe contener tres comillas simples seguidas,
para poder enviarlo dentro de un string sin problemas.
"""

import math
import os
import re

import bmesh
import bpy
from mathutils import Vector

PREFIJOS_COLISION = ("UBX_", "UCX_", "USP_", "UCS_", "UCL_", "UTM_")
PREFIJOS_ESPECIALES = PREFIJOS_COLISION + ("OCC_", "COM_", "SOCKET_", "BOXVOL_", "SPHVOL_")
RE_SUFIJO_BLENDER = re.compile(r"\.\d{3}$")
RE_LOD = re.compile(r"^(.*)_LOD(\d+)$", re.IGNORECASE)
LIMITE_VERTICES_UCX = 255  # orientativo, VERIFICAR con el MQA de EBT
VERSION = "1.3"  # súbela al cambiar el archivo; la copia guardada en el .blend puede estar desfasada


# ---------------------------------------------------------------- colecciones

def _coleccion(nombre, padre=None):
    col = bpy.data.collections.get(nombre)
    if col is None:
        col = bpy.data.collections.new(nombre)
    padre = padre or bpy.context.scene.collection
    if col.name not in padre.children:
        padre.children.link(col)
    return col


def _sub(nombre, raiz, asset):
    """Subcolección con el nombre que espera EBT; si ya existe en otro asset, añade sufijo."""
    col = bpy.data.collections.get(nombre)
    if col is not None and col.name not in raiz.children:
        nombre = nombre + "_" + asset
    return _coleccion(nombre, raiz)


def col_asset(nombre_asset):
    """Crea REF_<asset> con las subcolecciones que espera EBT. Devuelve dict de colecciones."""
    raiz = _coleccion("REF_" + nombre_asset)
    return {
        "raiz": raiz,
        "visual": _coleccion(nombre_asset + "_Visual", raiz),
        "colliders": _sub("Colliders", raiz, nombre_asset),
        "memory": _sub("Memory Points", raiz, nombre_asset),
        "occluders": _sub("Occluders", raiz, nombre_asset),
    }


def mover_a(obj, col):
    """Desvincula obj de sus colecciones y lo enlaza solo a col."""
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    col.objects.link(obj)
    return obj


def referencia_humana(x=2.0, y=0.0):
    """Maniquí de 1,80 m fuera de la colección del asset (no se exporta)."""
    col = _coleccion("Referencias")
    nombre = "REF_HUMANO_180cm"
    if nombre in bpy.data.objects:
        return bpy.data.objects[nombre]
    malla = bpy.data.meshes.new(nombre)
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=16, radius1=0.25, radius2=0.25, depth=1.8)
    bmesh.ops.translate(bm, verts=bm.verts, vec=Vector((0, 0, 0.9)))
    bm.to_mesh(malla)
    bm.free()
    obj = bpy.data.objects.new(nombre, malla)
    obj.location = (x, y, 0)
    obj.display_type = "WIRE"
    col.objects.link(obj)
    return obj


# ---------------------------------------------------------------- colisiones

def set_usage(obj, preset):
    """Asigna la custom property 'usage' (layer preset de Enfusion)."""
    obj["usage"] = preset
    return obj


def _material_placeholder(nombre):
    mat = bpy.data.materials.get(nombre) or bpy.data.materials.new(nombre)
    mat.diffuse_color = (1.0, 0.2, 0.6, 0.5)
    return mat


def _verts_mundo(obj):
    dg = bpy.context.evaluated_depsgraph_get()
    ev = obj.evaluated_get(dg)
    me = ev.to_mesh()
    pts = [ev.matrix_world @ v.co for v in me.vertices]
    ev.to_mesh_clear()
    return pts


def crear_collider(origen, tipo="UBX", nombre=None, usage=None, game_mat=None, col=None,
                   angulo_simplificar=2.0):
    """Crea una colisión a partir de 'origen' (objeto o lista de objetos).

    tipo: UBX (caja alineada a ejes del mundo), UCX (envolvente convexa) o UTM (copia de la malla).
    usage: layer preset (VERIFICAR nombres en EBT). game_mat: nombre provisional del material de juego.
    Los vértices quedan en coordenadas de mundo y el objeto con transformación identidad.
    """
    objs = origen if isinstance(origen, (list, tuple)) else [origen]
    pts = []
    for o in objs:
        pts.extend(_verts_mundo(o))
    if not pts:
        raise ValueError("Origen sin vértices")
    tipo = tipo.upper()
    nombre = nombre or "%s_%s" % (tipo, objs[0].name.split("_LOD")[0])
    if not nombre.upper().startswith(tipo + "_"):
        nombre = tipo + "_" + nombre
    bm = bmesh.new()

    if tipo == "UBX":
        mn = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
        mx = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
        c = [Vector((x, y, z)) for x in (mn.x, mx.x) for y in (mn.y, mx.y) for z in (mn.z, mx.z)]
        v = [bm.verts.new(p) for p in c]
        # índices: x*4 + y*2 + z
        for cara in ((0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)):
            bm.faces.new([v[i] for i in cara])
    elif tipo == "UCX":
        for p in pts:
            bm.verts.new(p)
        res = bmesh.ops.convex_hull(bm, input=bm.verts[:])
        sobrantes = list({g for g in res["geom_unused"] + res["geom_interior"] if isinstance(g, bmesh.types.BMVert)})
        bmesh.ops.delete(bm, geom=sobrantes, context="VERTS")
        bmesh.ops.dissolve_limit(bm, angle_limit=math.radians(angulo_simplificar),
                                 verts=bm.verts[:], edges=bm.edges[:])
        bm.normal_update()
        no_planas = [f for f in bm.faces if len(f.verts) > 3 and
                     max(abs(f.normal.dot(v.co - f.verts[0].co)) for v in f.verts) > 1e-5]
        bmesh.ops.triangulate(bm, faces=no_planas)
    elif tipo == "UTM":
        for o in objs:
            dg = bpy.context.evaluated_depsgraph_get()
            ev = o.evaluated_get(dg)
            me = ev.to_mesh()
            tmp = bmesh.new()
            tmp.from_mesh(me)
            tmp.transform(ev.matrix_world)
            tmp_me = bpy.data.meshes.new("_tmp")
            tmp.to_mesh(tmp_me)
            tmp.free()
            bm.from_mesh(tmp_me)
            bpy.data.meshes.remove(tmp_me)
            ev.to_mesh_clear()
        bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=0.001)
    else:
        bm.free()
        raise ValueError("Tipo no soportado aquí: " + tipo)

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = bpy.data.meshes.new(nombre)
    bm.to_mesh(me)
    bm.free()
    obj = bpy.data.objects.new(nombre, me)
    obj.display_type = "WIRE"
    (col or objs[0].users_collection[0]).objects.link(obj)
    if usage:
        set_usage(obj, usage)
    if game_mat:
        obj.data.materials.append(_material_placeholder(game_mat))
    return obj


# ---------------------------------------------------------------- LODs

def crear_lods(obj_lod0, ratios=(0.5, 0.25, 0.1), ocultar=True, angulo_duro=35.0):
    """Genera _LOD1.._LODn decimando una copia (con modificadores aplicados) de obj_lod0.
    El diezmado encoge un poco la silueta (mm): comprobar visualmente cada LOD."""
    m = RE_LOD.match(obj_lod0.name)
    if not m or int(m.group(2)) != 0:
        raise ValueError("El objeto debe llamarse <Nombre>_LOD0")
    base = m.group(1)
    creados = []
    for i, ratio in enumerate(ratios, start=1):
        nombre = "%s_LOD%d" % (base, i)
        viejo = bpy.data.objects.get(nombre)
        if viejo:
            bpy.data.objects.remove(viejo, do_unlink=True)
        nuevo = obj_lod0.copy()
        nuevo.data = obj_lod0.data.copy()
        nuevo.name = nombre
        for c in obj_lod0.users_collection:
            c.objects.link(nuevo)
        dec = nuevo.modifiers.new("LOD_Decimate", "DECIMATE")
        dec.ratio = ratio
        dec.use_collapse_triangulate = False
        dg = bpy.context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(nuevo.evaluated_get(dg))
        viejo_me = nuevo.data
        nuevo.modifiers.clear()
        nuevo.data = me
        me.name = nombre
        if viejo_me.users == 0:
            bpy.data.meshes.remove(viejo_me)
        # el diezmado rompe las normales personalizadas: rehacer aristas duras por ángulo
        for p in me.polygons:
            p.use_smooth = True
        me.set_sharp_from_angle(angle=math.radians(angulo_duro))
        if ocultar:
            nuevo.hide_set(True)
        creados.append({"nombre": nombre, "tris": sum(len(p.vertices) - 2 for p in me.polygons)})
    return creados


# ---------------------------------------------------------------- UVs

def uv_caja(obj, escala=1.0, nombre_capa="UVMap"):
    """UVs por proyección de caja según la normal dominante (1 m = escala unidades UV).
    Útil para materiales tileables (hormigón, ladrillo, chapa). Borra otras capas UV,
    por ejemplo las que heredan los booleanos de sus cortadores."""
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)
    uv = bm.loops.layers.uv.get(nombre_capa) or bm.loops.layers.uv.new(nombre_capa)
    for f in bm.faces:
        n = f.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        for lp in f.loops:
            co = lp.vert.co
            if ax == 0:
                lp[uv].uv = (co.y * escala, co.z * escala)
            elif ax == 1:
                lp[uv].uv = (co.x * escala, co.z * escala)
            else:
                lp[uv].uv = (co.x * escala, co.y * escala)
    bm.to_mesh(me)
    bm.free()
    for capa in [c for c in me.uv_layers if c.name != nombre_capa]:
        me.uv_layers.remove(capa)
    return obj


# ---------------------------------------------------------------- materiales

def material_preview(nombre, bcr=None, nmo=None, color=(0.5, 0.5, 0.5), rugosidad=0.8,
                     metal=0.0, invertir_g=False):
    """Material de vista previa. Desempaqueta BCR (RGB color, A rugosidad) y
    NMO (RG normal, B metalness, A AO). La Z de la normal se aproxima (solo preview)."""
    mat = bpy.data.materials.get(nombre) or bpy.data.materials.new(nombre)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    out.location = (600, 0)
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (300, 0)
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    bsdf.inputs["Base Color"].default_value = (*color, 1.0)
    bsdf.inputs["Roughness"].default_value = rugosidad
    bsdf.inputs["Metallic"].default_value = metal

    if bcr:
        img = bpy.data.images.load(bcr, check_existing=True)
        img.colorspace_settings.name = "sRGB"
        img.alpha_mode = "CHANNEL_PACKED"
        n = nt.nodes.new("ShaderNodeTexImage")
        n.image = img
        n.location = (-400, 200)
        nt.links.new(n.outputs["Color"], bsdf.inputs["Base Color"])
        nt.links.new(n.outputs["Alpha"], bsdf.inputs["Roughness"])
    if nmo:
        img = bpy.data.images.load(nmo, check_existing=True)
        img.colorspace_settings.name = "Non-Color"
        img.alpha_mode = "CHANNEL_PACKED"
        n = nt.nodes.new("ShaderNodeTexImage")
        n.image = img
        n.location = (-700, -200)
        sep = nt.nodes.new("ShaderNodeSeparateColor")
        sep.location = (-400, -200)
        nt.links.new(n.outputs["Color"], sep.inputs["Color"])
        nt.links.new(sep.outputs["Blue"], bsdf.inputs["Metallic"])
        verde = sep.outputs["Green"]
        if invertir_g:
            inv = nt.nodes.new("ShaderNodeMath")
            inv.operation = "SUBTRACT"
            inv.inputs[0].default_value = 1.0
            nt.links.new(sep.outputs["Green"], inv.inputs[1])
            verde = inv.outputs[0]
        comb = nt.nodes.new("ShaderNodeCombineColor")
        comb.location = (-150, -250)
        comb.inputs["Blue"].default_value = 1.0
        nt.links.new(sep.outputs["Red"], comb.inputs["Red"])
        nt.links.new(verde, comb.inputs["Green"])
        nm = nt.nodes.new("ShaderNodeNormalMap")
        nm.location = (50, -250)
        nt.links.new(comb.outputs["Color"], nm.inputs["Color"])
        nt.links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])
    return mat


# ---------------------------------------------------------------- revisión (mini MQA)

def _es_colision(nombre):
    return nombre.upper().startswith(PREFIJOS_COLISION)


def _es_especial(nombre):
    return nombre.upper().startswith(PREFIJOS_ESPECIALES)


def revisar_escena(nombre_coleccion):
    """Revisa la colección del asset y devuelve errores y avisos. No modifica nada."""
    col = bpy.data.collections.get(nombre_coleccion)
    if col is None:
        return {"error": "No existe la colección " + nombre_coleccion}
    errores, avisos, info = [], [], {}
    lods = {}
    for o in col.all_objects:
        n = o.name
        if RE_SUFIJO_BLENDER.search(n):
            errores.append("%s: sufijo .00x, Enfusion puede ignorarlo" % n)
        if o.type == "MESH":
            if any(abs(s - 1.0) > 1e-4 for s in o.scale):
                errores.append("%s: escala sin aplicar %s" % (n, tuple(round(s, 3) for s in o.scale)))
            if any(abs(r) > 1e-4 for r in o.rotation_euler) and not o.parent:
                avisos.append("%s: rotación sin aplicar" % n)
            me = o.data
            if _es_colision(n):
                u = o.get("usage")
                if u is None:
                    errores.append("%s: colisión sin propiedad 'usage'" % n)
                elif not str(u).strip():
                    errores.append("%s: 'usage' vacío" % n)
                if not me.materials or me.materials[0] is None:
                    errores.append("%s: colisión sin material de juego" % n)
                elif me.materials[0].name.startswith("GM_"):
                    avisos.append("%s: material de juego provisional '%s' (asignar con EBT)" % (n, me.materials[0].name))
                if n.upper().startswith("UCX_"):
                    bm = bmesh.new()
                    bm.from_mesh(me)
                    nm = sum(1 for e in bm.edges if not e.is_manifold)
                    np_ = 0
                    for f in bm.faces:
                        if len(f.verts) > 3:
                            d = max(abs(f.normal.dot(v.co - f.verts[0].co)) for v in f.verts)
                            if d > 1e-4:
                                np_ += 1
                    bm.free()
                    if nm:
                        errores.append("%s: %d bordes non-manifold" % (n, nm))
                    if np_:
                        errores.append("%s: %d caras no planas" % (n, np_))
                    if len(me.vertices) > LIMITE_VERTICES_UCX:
                        avisos.append("%s: %d vértices en UCX (simplificar)" % (n, len(me.vertices)))
            elif not _es_especial(n):
                if not me.uv_layers:
                    errores.append("%s: sin UVs" % n)
                elif len(me.uv_layers) > 2:
                    avisos.append("%s: %d capas UV (¿heredadas de booleanos?)" % (n, len(me.uv_layers)))
                if not me.materials or any(m is None for m in me.materials):
                    errores.append("%s: sin material o con huecos de material" % n)
                for m in me.materials:
                    if m and (m.name.startswith("Material") or RE_SUFIJO_BLENDER.search(m.name)):
                        avisos.append("%s: nombre de material poco claro '%s'" % (n, m.name))
                ml = RE_LOD.match(n)
                if ml:
                    lods.setdefault(ml.group(1), []).append(int(ml.group(2)))
                    if int(ml.group(2)) == 0:
                        dims = o.dimensions
                        tris = sum(len(p.vertices) - 2 for p in me.polygons)
                        info[n] = {"dimensiones_m": [round(d, 3) for d in dims], "tris_aprox": tris}
                else:
                    avisos.append("%s: malla visual sin sufijo _LODx" % n)
                if any(m.type == "ARMATURE" for m in o.modifiers):
                    pesados = set()
                    for v in me.vertices:
                        if any(g.weight > 0 for g in v.groups):
                            pesados.add(v.index)
                    sin = len(me.vertices) - len(pesados)
                    if sin:
                        errores.append("%s: %d vértices sin peso (se pesarán al root)" % (n, sin))
    for base, idx in lods.items():
        idx = sorted(idx)
        if idx != list(range(len(idx))):
            errores.append("%s: LODs con huecos o sin LOD0 %s" % (base, idx))
    return {"errores": errores, "avisos": avisos, "info_lod0": info}


# ---------------------------------------------------------------- exportación

def exportar_fbx(ruta_fbx, nombre_coleccion, excluir_prefijos=("REF_HUMANO",), solo_objetos=None):
    """Exporta la colección (o la lista solo_objetos) con los ajustes que pide Enfusion."""
    col = bpy.data.collections.get(nombre_coleccion)
    if col is None and not solo_objetos:
        raise ValueError("No existe la colección " + nombre_coleccion)
    objetos = solo_objetos or [o for o in col.all_objects if not o.name.startswith(excluir_prefijos)]
    if bpy.context.object and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    ocultos = [o for o in objetos if o.hide_get()]
    for o in ocultos:
        o.hide_set(False)
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    for o in objetos:
        o.select_set(True)
    os.makedirs(os.path.dirname(ruta_fbx), exist_ok=True)
    bpy.ops.export_scene.fbx(
        filepath=ruta_fbx,
        use_selection=True,
        object_types={"EMPTY", "ARMATURE", "MESH"},
        use_custom_props=True,
        add_leaf_bones=False,
        use_triangles=False,
        use_mesh_modifiers=True,
        apply_unit_scale=True,
        apply_scale_options="FBX_SCALE_NONE",
        global_scale=1.0,
        bake_anim=False,
        path_mode="AUTO",
    )
    for o in ocultos:
        o.hide_set(True)
    return {"exportado": ruta_fbx, "objetos": [o.name for o in objetos]}


# ---------------------------------------------------------------- guardado

def guardar_version():
    """Guarda una copia <archivo>_vNN.blend junto al .blend actual sin cambiar el archivo abierto."""
    ruta = bpy.data.filepath
    if not ruta:
        return {"error": "El .blend no se ha guardado nunca: pide una ruta al usuario"}
    carpeta, archivo = os.path.split(ruta)
    base = re.sub(r"_v\d+$", "", os.path.splitext(archivo)[0])
    n = 1
    while os.path.exists(os.path.join(carpeta, "%s_v%02d.blend" % (base, n))):
        n += 1
    destino = os.path.join(carpeta, "%s_v%02d.blend" % (base, n))
    bpy.ops.wm.save_as_mainfile(filepath=destino, copy=True)
    return {"guardado": destino}
