// POPCity Extra - Taquillas personales.
// Acción "Abrir mi taquilla". Corre solo en el cliente y pide la apertura al servidor,
// que es quien comprueba distancia, personaje y carga los datos.

class PCX_TaquillaUserAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool HasLocalEffectOnlyScript()
	{
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;

		CharacterControllerComponent controlador = CharacterControllerComponent.Cast(user.FindComponent(CharacterControllerComponent));
		return controlador && !controlador.IsDead() && !controlador.IsUnconscious();
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity || pUserEntity != SCR_PlayerController.GetLocalControlledEntity())
			return;

		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerController());
		if (pc)
			pc.PCX_PedirAbrirTaquilla();
	}
}
