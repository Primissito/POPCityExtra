// POPCity Extra - Taquillas personales.
// Solo servidor. Gestiona las sesiones abiertas:
//   abrir  -> crea el almacén personal junto a la taquilla, carga el JSON y abre el inventario nativo
//   usar   -> guarda el JSON cuando cambia algo (y cada minuto por seguridad)
//   cerrar -> al cerrar el inventario, alejarse, morir o desconectarse: guarda y borra el almacén
// Los datos van por personaje de POPCity (characterId), así cada personaje tiene su taquilla.

class PCX_TaquillaSesion
{
	int m_iPlayerId;
	string m_sClave;
	IEntity m_Almacen;
	IEntity m_Taquilla;
	bool m_bLista;			// restauración terminada
	bool m_bCerrando;		// pendiente de cerrar (se reintenta si falla el guardado)
	int m_iUltimoGuardado;
	ref PCX_TaquillaRestaurador m_Restaurador;
	ref array<ref PCX_TaquillaObjeto> m_aNoRestaurados = {};
}

//------------------------------------------------------------------------------------------------
class PCX_TaquillaServicio
{
	protected static const string CARPETA = "$profile:PCX";
	protected static const string CARPETA_TAQUILLAS = "$profile:PCX/Taquillas";
	protected static const string CARACTERES_VALIDOS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_";
	protected static const float DISTANCIA_USO = 2.5;			// para abrir
	protected static const float DISTANCIA_MAXIMA = 3.5;		// si te alejas más, se cierra
	protected static const int INTERVALO_TICK_MS = 2000;
	protected static const int GUARDADO_FORZADO_MS = 60000;

	protected static ref map<int, ref PCX_TaquillaSesion> s_mSesiones = new map<int, ref PCX_TaquillaSesion>();

	//------------------------------------------------------------------------------------------------
	//! Petición del jugador (llega por RPC desde SCR_PlayerController).
	static void Abrir(int playerId)
	{
		if (!Replication.IsServer())
			return;

		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerManager().GetPlayerController(playerId));
		if (!pc)
			return;

		IEntity pawn = pc.GetControlledEntity();
		if (!JugadorLibre(pawn))
		{
			pc.PCX_AvisoTaquilla("Ahora no puedes usar la taquilla.", true);
			return;
		}

		PCX_TaquillaComponent taquilla = PCX_TaquillaComponent.BuscarCercana(pawn.GetOrigin(), DISTANCIA_USO);
		if (!taquilla)
		{
			pc.PCX_AvisoTaquilla("Acércate más a la taquilla.", true);
			return;
		}

		PCX_TaquillaSesion sesion;
		if (s_mSesiones.Find(playerId, sesion) && sesion)
		{
			bool almacenVivo = sesion.m_Almacen && !sesion.m_Almacen.IsDeleted();
			if (!sesion.m_bLista || sesion.m_bCerrando)
			{
				pc.PCX_AvisoTaquilla("Tu taquilla se está preparando, espera un momento.", false);
				return;
			}

			if (almacenVivo && sesion.m_Taquilla == taquilla.GetOwner())
			{
				EnviarAbrir(pc, sesion);
				return;
			}

			if (!Cerrar(playerId))
			{
				pc.PCX_AvisoTaquilla("Tu taquilla se está guardando, espera un momento.", false);
				return;
			}
		}

		string clave = ObtenerClave(playerId);
		if (clave.IsEmpty())
		{
			pc.PCX_AvisoTaquilla("Tu personaje aún no está listo. Inténtalo en unos segundos.", true);
			return;
		}

		Resource prefab = Resource.Load(taquilla.GetPrefabAlmacen());
		if (!prefab || !prefab.IsValid())
		{
			Print("[PCX_Taquillas] La taquilla no tiene un prefab de almacén válido.", LogLevel.ERROR);
			pc.PCX_AvisoTaquilla("Esta taquilla no está bien configurada.", true);
			return;
		}

		PCX_TaquillaDatos datos = Cargar(clave);
		if (!datos)
		{
			// JSON corrupto: no se abre para no sobrescribirlo. Un admin puede revisarlo.
			pc.PCX_AvisoTaquilla("No se pudo leer tu taquilla. Avisa a un administrador.", true);
			return;
		}

		EntitySpawnParams parametros = new EntitySpawnParams();
		parametros.TransformMode = ETransformMode.WORLD;
		taquilla.GetOwner().GetWorldTransform(parametros.Transform);
		parametros.Transform[3] = taquilla.GetPosicionAlmacenMundo();

		IEntity almacen = GetGame().SpawnEntityPrefab(prefab, GetGame().GetWorld(), parametros);
		PCX_TaquillaGestorComponent gestor;
		if (almacen)
			gestor = PCX_TaquillaGestorComponent.Cast(almacen.FindComponent(PCX_TaquillaGestorComponent));

		if (!gestor || !AlmacenRaiz(almacen))
		{
			if (almacen)
				SCR_EntityHelper.DeleteEntityAndChildren(almacen);

			Print("[PCX_Taquillas] El prefab del almacén necesita PCX_TaquillaGestorComponent y un almacenamiento.", LogLevel.ERROR);
			pc.PCX_AvisoTaquilla("Esta taquilla no está bien configurada.", true);
			return;
		}

		gestor.PCX_Configurar(playerId);

		sesion = new PCX_TaquillaSesion();
		sesion.m_iPlayerId = playerId;
		sesion.m_sClave = clave;
		sesion.m_Almacen = almacen;
		sesion.m_Taquilla = taquilla.GetOwner();
		sesion.m_iUltimoGuardado = System.GetTickCount();
		s_mSesiones.Set(playerId, sesion);

		Print(string.Format("[PCX_Taquillas] Abriendo taquilla de %1 (%2 objetos guardados).", clave, datos.m_aObjetos.Count()), LogLevel.NORMAL);

		sesion.m_Restaurador = new PCX_TaquillaRestaurador(sesion, gestor, datos);
		sesion.m_Restaurador.Iniciar();
		IniciarTick();
	}

	//------------------------------------------------------------------------------------------------
	//! Lo llama el restaurador cuando todos los objetos están dentro.
	static void AlRestaurar(PCX_TaquillaSesion sesion)
	{
		if (!sesion)
			return;

		sesion.m_bLista = true;

		PCX_TaquillaGestorComponent gestor = ObtenerGestor(sesion);
		if (gestor)
		{
			gestor.PCX_SetAbierto(true);
			gestor.PCX_ConsumirCambios();
		}

		if (sesion.m_bCerrando)
			return; // el tick la cierra

		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerManager().GetPlayerController(sesion.m_iPlayerId));
		if (!pc)
			return;

		if (!sesion.m_aNoRestaurados.IsEmpty())
			pc.PCX_AvisoTaquilla("Algunos objetos no se han podido sacar, pero siguen guardados.", true);

		EnviarAbrir(pc, sesion);
	}

	//------------------------------------------------------------------------------------------------
	//! El cliente ha cerrado el inventario.
	static void CerrarPorCliente(int playerId)
	{
		PCX_TaquillaSesion sesion;
		if (!s_mSesiones.Find(playerId, sesion) || !sesion)
			return;

		sesion.m_bCerrando = true;
		if (sesion.m_bLista)
			Cerrar(playerId);
	}

	//------------------------------------------------------------------------------------------------
	//! Guarda y borra el almacén. Devuelve false si no se pudo (se reintentará en el tick).
	protected static bool Cerrar(int playerId)
	{
		PCX_TaquillaSesion sesion;
		if (!s_mSesiones.Find(playerId, sesion) || !sesion)
			return true;

		sesion.m_bCerrando = true;
		if (!sesion.m_bLista)
			return false;

		PCX_TaquillaGestorComponent gestor = ObtenerGestor(sesion);
		if (gestor)
			gestor.PCX_SetAbierto(false);

		if (sesion.m_Almacen && !sesion.m_Almacen.IsDeleted())
		{
			if (!Guardar(sesion))
				return false; // el almacén se queda en el mundo hasta poder guardar

			SCR_EntityHelper.DeleteEntityAndChildren(sesion.m_Almacen);
		}

		if (sesion.m_Restaurador)
			sesion.m_Restaurador.Cancelar();

		string clave = sesion.m_sClave;
		s_mSesiones.Remove(playerId);
		SincronizarPersonaje(playerId, clave);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected static void Tick()
	{
		array<int> cerrar = {};
		array<int> descartar = {};

		foreach (int playerId, PCX_TaquillaSesion sesion : s_mSesiones)
		{
			if (!sesion)
			{
				descartar.Insert(playerId);
				continue;
			}

			if (!sesion.m_bLista)
				continue;

			// Almacén borrado por otra cosa (fin de partida en Workbench, etc.).
			if (!sesion.m_Almacen || sesion.m_Almacen.IsDeleted())
			{
				descartar.Insert(playerId);
				continue;
			}

			if (sesion.m_bCerrando || !SigueUsandola(sesion))
			{
				cerrar.Insert(playerId);
				continue;
			}

			PCX_TaquillaGestorComponent gestor = ObtenerGestor(sesion);
			bool cambios = gestor && gestor.PCX_ConsumirCambios();
			if (cambios || System.GetTickCount(sesion.m_iUltimoGuardado) > GUARDADO_FORZADO_MS)
			{
				if (Guardar(sesion) && cambios)
					SincronizarPersonaje(playerId, sesion.m_sClave);
			}
		}

		foreach (int idDescartar : descartar)
			s_mSesiones.Remove(idDescartar);

		foreach (int idCerrar : cerrar)
			Cerrar(idCerrar);

		if (s_mSesiones.IsEmpty())
			GetGame().GetCallqueue().Remove(Tick);
	}

	//------------------------------------------------------------------------------------------------
	protected static void IniciarTick()
	{
		GetGame().GetCallqueue().Remove(Tick);
		GetGame().GetCallqueue().CallLater(Tick, INTERVALO_TICK_MS, true);
	}

	//------------------------------------------------------------------------------------------------
	protected static bool SigueUsandola(PCX_TaquillaSesion sesion)
	{
		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerManager().GetPlayerController(sesion.m_iPlayerId));
		if (!pc)
			return false; // desconectado

		IEntity pawn = pc.GetControlledEntity();
		if (!JugadorLibre(pawn))
			return false;

		// Si alguien ha conseguido meter el almacén en un inventario, se cierra.
		if (sesion.m_Almacen.GetParent())
			return false;

		return vector.DistanceSq(pawn.GetOrigin(), sesion.m_Almacen.GetOrigin()) <= DISTANCIA_MAXIMA * DISTANCIA_MAXIMA;
	}

	//------------------------------------------------------------------------------------------------
	protected static bool JugadorLibre(IEntity pawn)
	{
		if (!pawn || pawn.IsDeleted())
			return false;

		CharacterControllerComponent controlador = CharacterControllerComponent.Cast(pawn.FindComponent(CharacterControllerComponent));
		return controlador && !controlador.IsDead() && !controlador.IsUnconscious();
	}

	//------------------------------------------------------------------------------------------------
	protected static void EnviarAbrir(SCR_PlayerController pc, PCX_TaquillaSesion sesion)
	{
		RplComponent rpl = RplComponent.Cast(sesion.m_Almacen.FindComponent(RplComponent));
		if (!rpl)
		{
			Print("[PCX_Taquillas] El almacén no tiene RplComponent.", LogLevel.ERROR);
			return;
		}

		pc.PCX_AbrirTaquillaEnCliente(rpl.Id());
	}

	//------------------------------------------------------------------------------------------------
	protected static PCX_TaquillaGestorComponent ObtenerGestor(PCX_TaquillaSesion sesion)
	{
		if (!sesion || !sesion.m_Almacen || sesion.m_Almacen.IsDeleted())
			return null;

		return PCX_TaquillaGestorComponent.Cast(sesion.m_Almacen.FindComponent(PCX_TaquillaGestorComponent));
	}

	//------------------------------------------------------------------------------------------------
	protected static BaseInventoryStorageComponent AlmacenRaiz(IEntity almacen)
	{
		if (!almacen)
			return null;

		return BaseInventoryStorageComponent.Cast(almacen.FindComponent(BaseInventoryStorageComponent));
	}

	//------------------------------------------------------------------------------------------------
	//! Identificador del dueño de la taquilla: el personaje de POPCity.
	static string ObtenerClave(int playerId)
	{
		ARL_CharacterData personaje = ARL_BackendClient.GetSelectedCharacterData(playerId);
		if (personaje && !personaje.characterId.IsEmpty() && ARL_CharacterPersistenceService.IsCharacterActivated(playerId))
			return Limpiar("pj_" + personaje.characterId);

#ifdef WORKBENCH
		// Solo para probar en Workbench, donde el backend de POPCity no responde.
		string identidad;
		PlayerController pcLocal = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pcLocal && pcLocal.GetControlledEntity())
			identidad = SCR_PlayerIdentityUtils.GetPlayerIdentityId(pcLocal.GetControlledEntity());

		if (identidad.IsEmpty())
			identidad = "local" + playerId.ToString();

		return Limpiar("wb_" + identidad);
#else
		return string.Empty;
#endif
	}

	//------------------------------------------------------------------------------------------------
	protected static string Limpiar(string texto)
	{
		string resultado;
		for (int i = 0; i < texto.Length(); i++)
		{
			string caracter = texto.Get(i);
			if (CARACTERES_VALIDOS.Contains(caracter))
				resultado += caracter;
			else
				resultado += "_";
		}
		return resultado;
	}

	//------------------------------------------------------------------------------------------------
	protected static string Ruta(string clave)
	{
		return CARPETA_TAQUILLAS + "/" + clave + ".json";
	}

	//------------------------------------------------------------------------------------------------
	//! null = el archivo existe pero no se puede leer (no se debe sobrescribir).
	protected static PCX_TaquillaDatos Cargar(string clave)
	{
		PCX_TaquillaDatos datos = new PCX_TaquillaDatos();
		datos.m_sClave = clave;

		string ruta = Ruta(clave);
		if (!FileIO.FileExists(ruta))
			return datos;

		SCR_JsonLoadContext contexto = new SCR_JsonLoadContext();
		if (!contexto.LoadFromFile(ruta) || !contexto.ReadValue("", datos))
		{
			Print("[PCX_Taquillas] No se puede leer " + ruta + ". No se abre para no perder datos.", LogLevel.ERROR);
			return null;
		}

		return datos;
	}

	//------------------------------------------------------------------------------------------------
	protected static bool Guardar(PCX_TaquillaSesion sesion)
	{
		BaseInventoryStorageComponent raiz = AlmacenRaiz(sesion.m_Almacen);
		if (!raiz)
			return false;

		PCX_TaquillaDatos datos = new PCX_TaquillaDatos();
		datos.m_sClave = sesion.m_sClave;

		array<IEntity> objetos = {};
		raiz.GetAll(objetos, false);
		foreach (IEntity objeto : objetos)
		{
			PCX_TaquillaObjeto capturado = Capturar(objeto);
			if (capturado)
				datos.m_aObjetos.Insert(capturado);
		}

		foreach (PCX_TaquillaObjeto pendiente : sesion.m_aNoRestaurados)
		{
			if (pendiente)
				datos.m_aObjetos.Insert(pendiente);
		}

		if (!FileIO.FileExists(CARPETA))
			FileIO.MakeDirectory(CARPETA);

		if (!FileIO.FileExists(CARPETA_TAQUILLAS))
			FileIO.MakeDirectory(CARPETA_TAQUILLAS);

		SCR_JsonSaveContext contexto = new SCR_JsonSaveContext();
		contexto.WriteValue("", datos);
		string ruta = Ruta(sesion.m_sClave);
		if (!contexto.SaveToFile(ruta))
		{
			Print("[PCX_Taquillas] Error al guardar " + ruta, LogLevel.ERROR);
			return false;
		}

		sesion.m_iUltimoGuardado = System.GetTickCount();
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected static PCX_TaquillaObjeto Capturar(IEntity objeto)
	{
		if (!objeto || objeto.IsDeleted())
			return null;

		EntityPrefabData prefabData = objeto.GetPrefabData();
		if (!prefabData)
			return null;

		ResourceName prefab = prefabData.GetPrefabName();
		if (prefab.IsEmpty())
			return null;

		PCX_TaquillaObjeto datos = new PCX_TaquillaObjeto();
		datos.m_sPrefab = prefab;

		InventoryItemComponent item = InventoryItemComponent.Cast(objeto.FindComponent(InventoryItemComponent));
		if (item)
		{
			InventoryStorageSlot ranura = item.GetParentSlot();
			if (ranura)
			{
				datos.m_iRanura = ranura.GetID();
				datos.m_iAlmacen = IndiceAlmacen(ranura.GetStorage());
			}
		}

		BaseMagazineComponent cargador = BaseMagazineComponent.Cast(objeto.FindComponent(BaseMagazineComponent));
		if (cargador)
			datos.m_iMunicion = cargador.GetAmmoCount();

		DamageManagerComponent danos = DamageManagerComponent.Cast(objeto.FindComponent(DamageManagerComponent));
		if (danos)
		{
			HitZone zona = danos.GetDefaultHitZone();
			if (zona)
				datos.m_fSalud = zona.GetHealthScaled();
		}

		array<Managed> almacenes = {};
		objeto.FindComponents(BaseInventoryStorageComponent, almacenes);
		foreach (Managed bruto : almacenes)
		{
			BaseInventoryStorageComponent almacen = BaseInventoryStorageComponent.Cast(bruto);
			if (!almacen)
				continue;

			array<IEntity> hijos = {};
			almacen.GetAll(hijos, false);
			foreach (IEntity hijo : hijos)
			{
				PCX_TaquillaObjeto datosHijo = Capturar(hijo);
				if (datosHijo)
					datos.m_aContenido.Insert(datosHijo);
			}
		}

		return datos;
	}

	//------------------------------------------------------------------------------------------------
	protected static int IndiceAlmacen(BaseInventoryStorageComponent almacen)
	{
		if (!almacen || !almacen.GetOwner())
			return -1;

		array<Managed> almacenes = {};
		almacen.GetOwner().FindComponents(BaseInventoryStorageComponent, almacenes);
		return almacenes.Find(almacen);
	}

	//------------------------------------------------------------------------------------------------
	//! Tras guardar la taquilla, POPCity guarda el inventario del personaje en su backend
	//! enseguida (así el objeto no queda a la vez en la taquilla y en el personaje).
	protected static void SincronizarPersonaje(int playerId, string clave)
	{
		if (clave.IndexOf("pj_") != 0)
			return;

		ARL_CharacterPersistenceService.SynchronizeInventoryAfterStorePurchase(playerId);
	}
}
