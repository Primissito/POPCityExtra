// POPCity Extra - Taquillas personales.
// Solo cliente. Abre el inventario nativo del juego con el almacén personal y avisa al
// servidor cuando se cierra. Además oculta a los demás los almacenes que no son suyos.

class PCX_TaquillaCliente
{
	protected static const int MAX_INTENTOS = 30;	// 30 x 100 ms = 3 s esperando a que llegue el almacén

	protected static RplId s_IdPendiente;
	protected static int s_iIntentos;
	protected static IEntity s_AlmacenAbierto;

	//------------------------------------------------------------------------------------------------
	static void Abrir(RplId almacenId)
	{
		GetGame().GetCallqueue().Remove(Intentar);
		s_IdPendiente = almacenId;
		s_iIntentos = 0;
		Intentar();
	}

	//------------------------------------------------------------------------------------------------
	//! Espera a que el almacén se haya replicado y aparezca en las cercanías del jugador.
	protected static void Intentar()
	{
		IEntity almacen = BuscarEntidad(s_IdPendiente);
		IEntity pawn = SCR_PlayerController.GetLocalControlledEntity();

		bool enCercanias;
		if (almacen && pawn)
		{
			CharacterVicinityComponent cercanias = CharacterVicinityComponent.Cast(pawn.FindComponent(CharacterVicinityComponent));
			if (cercanias)
			{
				array<IEntity> disponibles = {};
				cercanias.GetAvailableItems(disponibles);
				enCercanias = disponibles.Contains(almacen);
			}
		}

		s_iIntentos++;
		if (!enCercanias && s_iIntentos < MAX_INTENTOS)
		{
			GetGame().GetCallqueue().CallLater(Intentar, 100, false);
			return;
		}

		if (!almacen || !pawn)
		{
			ARL_NativeMessageManager.ShowError("No se ha podido abrir la taquilla. Inténtalo de nuevo.");
			return;
		}

		if (!enCercanias)
			Print("[PCX_Taquillas] El almacén no aparece en las cercanías; se intenta abrir igualmente.", LogLevel.WARNING);

		SCR_InventoryStorageManagerComponent inventario = SCR_InventoryStorageManagerComponent.Cast(pawn.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inventario)
			return;

		s_AlmacenAbierto = almacen;
		inventario.SetStorageToOpen(almacen);
		inventario.OpenInventory();
	}

	//------------------------------------------------------------------------------------------------
	protected static IEntity BuscarEntidad(RplId id)
	{
		if (!id.IsValid())
			return null;

		RplComponent rpl = RplComponent.Cast(Replication.FindItem(id));
		if (!rpl)
			return null;

		return rpl.GetEntity();
	}

	//------------------------------------------------------------------------------------------------
	//! Lo llama el inventario al cerrarse.
	static void AlCerrarInventario()
	{
		if (!s_AlmacenAbierto)
			return;

		s_AlmacenAbierto = null;
		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerController());
		if (pc)
			pc.PCX_PedirCerrarTaquilla();
	}

	//------------------------------------------------------------------------------------------------
	//! false si la entidad es el almacén personal de otro jugador.
	static bool PuedoVer(IEntity entidad)
	{
		if (!entidad)
			return true;

		PCX_TaquillaGestorComponent gestor = PCX_TaquillaGestorComponent.Cast(entidad.FindComponent(PCX_TaquillaGestorComponent));
		if (!gestor)
			return true;

		PlayerController pc = GetGame().GetPlayerController();
		return pc && gestor.PCX_GetPropietario() == pc.GetPlayerId();
	}
}

//------------------------------------------------------------------------------------------------
modded class SCR_InventoryMenuUI
{
	override void OnMenuClose()
	{
		super.OnMenuClose();
		PCX_TaquillaCliente.AlCerrarInventario();
	}
}

//------------------------------------------------------------------------------------------------
modded class SCR_InventoryStorageLootUI
{
	// Los almacenes personales de otros jugadores no aparecen en "Cercanías".
	override protected SCR_InventorySlotUI CreateSlotUI(InventoryItemComponent pComponent, SCR_ItemAttributeCollection pAttributes = null)
	{
		if (pComponent && !PCX_TaquillaCliente.PuedoVer(pComponent.GetOwner()))
			return null;

		return super.CreateSlotUI(pComponent, pAttributes);
	}
}
