// POPCity Extra - Taquillas personales.
// Solo servidor. Vuelve a crear dentro del almacén personal los objetos guardados en el JSON,
// uno a uno y con su contenido (bolsillos, cargadores, accesorios).
// Si un objeto no se puede crear o meter, NO se pierde: se queda en la lista de
// "no restaurados" de la sesión y se vuelve a escribir en el JSON al guardar.

class PCX_TaquillaTarea
{
	ref PCX_TaquillaObjeto m_Datos;
	IEntity m_Padre;		// entidad que contiene el almacenamiento destino
	bool m_bRaiz;			// true = va directamente al almacén personal
	IEntity m_Existente;	// pieza de serie ya enganchada (ranuras de ropa): se reutiliza
}

//------------------------------------------------------------------------------------------------
class PCX_TaquillaInsercionCallback : ScriptedInventoryOperationCallback
{
	PCX_TaquillaRestaurador m_Restaurador;	// sin ref: el restaurador es el dueño del callback
	int m_iSerie;

	override protected void OnComplete()
	{
		if (m_Restaurador)
			m_Restaurador.AlTerminarInsercion(m_iSerie, true);
	}

	override protected void OnFailed()
	{
		if (m_Restaurador)
			m_Restaurador.AlTerminarInsercion(m_iSerie, false);
	}
}

//------------------------------------------------------------------------------------------------
class PCX_TaquillaRestaurador
{
	protected static const int TIEMPO_MAX_INSERCION_MS = 5000;

	protected PCX_TaquillaSesion m_Sesion;			// sin ref: la sesión es la dueña del restaurador
	protected PCX_TaquillaGestorComponent m_Gestor;
	protected ref array<ref PCX_TaquillaTarea> m_aCola = {};
	protected ref PCX_TaquillaInsercionCallback m_Callback;
	protected ref PCX_TaquillaTarea m_Actual;
	protected IEntity m_ObjetoActual;
	protected int m_iRanuraActual;
	protected int m_iSerie;
	protected bool m_bTerminado;

	//------------------------------------------------------------------------------------------------
	void PCX_TaquillaRestaurador(PCX_TaquillaSesion sesion, PCX_TaquillaGestorComponent gestor, PCX_TaquillaDatos datos)
	{
		m_Sesion = sesion;
		m_Gestor = gestor;
		m_Callback = new PCX_TaquillaInsercionCallback();
		m_Callback.m_Restaurador = this;

		if (!datos)
			return;

		foreach (PCX_TaquillaObjeto objeto : datos.m_aObjetos)
		{
			if (!objeto)
				continue;

			PCX_TaquillaTarea tarea = new PCX_TaquillaTarea();
			tarea.m_Datos = objeto;
			tarea.m_Padre = gestor.GetOwner();
			tarea.m_bRaiz = true;
			m_aCola.Insert(tarea);
		}
	}

	//------------------------------------------------------------------------------------------------
	void ~PCX_TaquillaRestaurador()
	{
		Cancelar();
	}

	//------------------------------------------------------------------------------------------------
	void Iniciar()
	{
		GetGame().GetCallqueue().CallLater(Siguiente, 0, false);
	}

	//------------------------------------------------------------------------------------------------
	void Cancelar()
	{
		m_bTerminado = true;
		if (!GetGame())
			return;

		GetGame().GetCallqueue().Remove(Siguiente);
		GetGame().GetCallqueue().Remove(Vigilante);
	}

	//------------------------------------------------------------------------------------------------
	protected void Siguiente()
	{
		if (m_bTerminado)
			return;

		if (!m_Gestor || !m_Sesion)
		{
			m_bTerminado = true;
			return;
		}

		if (m_aCola.IsEmpty())
		{
			m_bTerminado = true;
			PCX_TaquillaServicio.AlRestaurar(m_Sesion);
			return;
		}

		m_Actual = m_aCola[0];
		m_aCola.RemoveOrdered(0);
		m_ObjetoActual = null;

		// Pieza que el prefab padre ya trae enganchada (bolsillos de un harness, etc.).
		if (m_Actual.m_Existente && !m_Actual.m_Existente.IsDeleted())
		{
			m_ObjetoActual = m_Actual.m_Existente;
			ProcesarColocado();
			return;
		}

		BaseInventoryStorageComponent destino = ResolverAlmacen(m_Actual);
		Resource recurso = Resource.Load(m_Actual.m_Datos.m_sPrefab);
		if (!destino || !recurso || !recurso.IsValid())
		{
			Fallo();
			return;
		}

		EntitySpawnParams parametros = new EntitySpawnParams();
		parametros.TransformMode = ETransformMode.WORLD;
		parametros.Transform[3] = m_Gestor.GetOwner().GetOrigin();
		m_ObjetoActual = GetGame().SpawnEntityPrefab(recurso, GetGame().GetWorld(), parametros);
		if (!m_ObjetoActual)
		{
			Fallo();
			return;
		}

		// En el almacén personal da igual la ranura; dentro de ropa/armas se respeta.
		m_iRanuraActual = m_Actual.m_Datos.m_iRanura;
		if (m_Actual.m_bRaiz)
			m_iRanuraActual = -1;

		Insertar(destino);
	}

	//------------------------------------------------------------------------------------------------
	protected void Insertar(BaseInventoryStorageComponent destino)
	{
		m_iSerie++;
		int serie = m_iSerie;
		m_Callback.m_iSerie = serie;
		GetGame().GetCallqueue().CallLater(Vigilante, TIEMPO_MAX_INSERCION_MS, false, serie);

		if (!m_Gestor.TryInsertItemInStorage(m_ObjetoActual, destino, m_iRanuraActual, m_Callback))
			AlTerminarInsercion(serie, false);
	}

	//------------------------------------------------------------------------------------------------
	//! Si una inserción no responde, se da por fallida (el objeto vuelve a "no restaurados").
	protected void Vigilante(int serie)
	{
		if (serie == m_iSerie)
			AlTerminarInsercion(serie, false);
	}

	//------------------------------------------------------------------------------------------------
	void AlTerminarInsercion(int serie, bool correcto)
	{
		if (m_bTerminado || serie != m_iSerie)
			return;

		// Invalida callbacks repetidos y el vigilante de esta inserción.
		m_iSerie++;
		GetGame().GetCallqueue().Remove(Vigilante);

		if (!correcto)
		{
			// Segundo intento en cualquier ranura libre.
			if (m_iRanuraActual != -1 && m_ObjetoActual)
			{
				m_iRanuraActual = -1;
				BaseInventoryStorageComponent destino = ResolverAlmacen(m_Actual);
				if (destino)
				{
					Insertar(destino);
					return;
				}
			}

			Fallo();
			return;
		}

		ProcesarColocado();
	}

	//------------------------------------------------------------------------------------------------
	//! El objeto actual ya está en su sitio: estado, contenido de serie y cola de hijos.
	protected void ProcesarColocado()
	{
		AplicarEstado(m_ObjetoActual, m_Actual.m_Datos);
		PrepararHijos(m_ObjetoActual, m_Actual.m_Datos);
		GetGame().GetCallqueue().CallLater(Siguiente, 0, false);
	}

	//------------------------------------------------------------------------------------------------
	//! El prefab puede traer cosas de serie (un arma con cargador, un harness con bolsillos).
	//! - En ranuras de ropa (ClothNodeStorageComponent) la pieza de serie se reutiliza si es la
	//!   misma que estaba guardada: no se puede quitar y volver a enganchar.
	//! - Todo lo demás de serie se quita y se mete exactamente lo guardado.
	protected void PrepararHijos(IEntity objeto, PCX_TaquillaObjeto datos)
	{
		array<Managed> almacenes = {};
		objeto.FindComponents(BaseInventoryStorageComponent, almacenes);

		array<IEntity> reutilizados = {};
		array<ref PCX_TaquillaTarea> nuevas = {};

		foreach (PCX_TaquillaObjeto datosHijo : datos.m_aContenido)
		{
			if (!datosHijo)
				continue;

			PCX_TaquillaTarea hija = new PCX_TaquillaTarea();
			hija.m_Datos = datosHijo;
			hija.m_Padre = objeto;

			int indice = datosHijo.m_iAlmacen;
			if (indice >= 0 && indice < almacenes.Count())
			{
				ClothNodeStorageComponent nodo = ClothNodeStorageComponent.Cast(almacenes[indice]);
				if (nodo && datosHijo.m_iRanura >= 0 && datosHijo.m_iRanura < nodo.GetSlotsCount())
				{
					IEntity existente = nodo.Get(datosHijo.m_iRanura);
					if (existente && !reutilizados.Contains(existente) && MismoPrefab(existente, datosHijo.m_sPrefab))
					{
						hija.m_Existente = existente;
						reutilizados.Insert(existente);
					}
				}
			}

			nuevas.Insert(hija);
		}

		foreach (Managed bruto : almacenes)
		{
			BaseInventoryStorageComponent almacen = BaseInventoryStorageComponent.Cast(bruto);
			if (!almacen)
				continue;

			array<IEntity> deSerie = {};
			almacen.GetAll(deSerie, false);
			foreach (IEntity pieza : deSerie)
			{
				if (pieza && !pieza.IsDeleted() && !reutilizados.Contains(pieza))
					SCR_EntityHelper.DeleteEntityAndChildren(pieza);
			}
		}

		for (int i = nuevas.Count() - 1; i >= 0; i--)
		{
			m_aCola.InsertAt(nuevas[i], 0);
		}
	}

	//------------------------------------------------------------------------------------------------
	protected bool MismoPrefab(IEntity entidad, string prefab)
	{
		EntityPrefabData prefabData = entidad.GetPrefabData();
		return prefabData && prefabData.GetPrefabName() == prefab;
	}

	//------------------------------------------------------------------------------------------------
	protected void Fallo()
	{
		if (m_ObjetoActual)
		{
			SCR_EntityHelper.DeleteEntityAndChildren(m_ObjetoActual);
			m_ObjetoActual = null;
		}

		if (m_Actual && m_Sesion)
		{
			m_Sesion.m_aNoRestaurados.Insert(m_Actual.m_Datos);
			Print(string.Format("[PCX_Taquillas] No se pudo restaurar %1 (clave %2). Se conserva en el guardado.", m_Actual.m_Datos.m_sPrefab, m_Sesion.m_sClave), LogLevel.WARNING);
		}

		GetGame().GetCallqueue().CallLater(Siguiente, 0, false);
	}

	//------------------------------------------------------------------------------------------------
	protected BaseInventoryStorageComponent ResolverAlmacen(PCX_TaquillaTarea tarea)
	{
		if (!tarea || !tarea.m_Padre || tarea.m_Padre.IsDeleted())
			return null;

		if (tarea.m_bRaiz)
			return BaseInventoryStorageComponent.Cast(tarea.m_Padre.FindComponent(BaseInventoryStorageComponent));

		array<Managed> almacenes = {};
		tarea.m_Padre.FindComponents(BaseInventoryStorageComponent, almacenes);
		if (almacenes.IsEmpty())
			return null;

		int indice = tarea.m_Datos.m_iAlmacen;
		if (indice < 0 || indice >= almacenes.Count())
			indice = 0;

		return BaseInventoryStorageComponent.Cast(almacenes[indice]);
	}

	//------------------------------------------------------------------------------------------------
	protected void AplicarEstado(IEntity objeto, PCX_TaquillaObjeto datos)
	{
		if (!objeto || !datos)
			return;

		if (datos.m_iMunicion >= 0)
		{
			BaseMagazineComponent cargador = BaseMagazineComponent.Cast(objeto.FindComponent(BaseMagazineComponent));
			if (cargador)
				cargador.SetAmmoCount(datos.m_iMunicion);
		}

		if (datos.m_fSalud < 1)
		{
			DamageManagerComponent danos = DamageManagerComponent.Cast(objeto.FindComponent(DamageManagerComponent));
			if (danos)
			{
				HitZone zona = danos.GetDefaultHitZone();
				if (zona)
					zona.SetHealthScaled(datos.m_fSalud);
			}
		}
	}
}
