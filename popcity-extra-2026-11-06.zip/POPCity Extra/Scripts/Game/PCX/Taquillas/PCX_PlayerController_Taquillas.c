// POPCity Extra - Taquillas personales.
// RPCs entre el cliente y el servidor. Mismo patrón que la taquilla de policía de POPCity.

modded class SCR_PlayerController
{
	protected int m_iPCXTaquillaUltimaPeticion;

	//------------------------------------------------------------------------------------------------
	// Cliente -> servidor
	//------------------------------------------------------------------------------------------------
	void PCX_PedirAbrirTaquilla()
	{
		Rpc(RpcAsk_PCX_AbrirTaquilla);
	}

	//------------------------------------------------------------------------------------------------
	void PCX_PedirCerrarTaquilla()
	{
		Rpc(RpcAsk_PCX_CerrarTaquilla);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	protected void RpcAsk_PCX_AbrirTaquilla()
	{
		if (!Replication.IsServer())
			return;

		// Anti-spam: una petición por segundo.
		if (m_iPCXTaquillaUltimaPeticion > 0 && System.GetTickCount(m_iPCXTaquillaUltimaPeticion) < 1000)
			return;

		m_iPCXTaquillaUltimaPeticion = System.GetTickCount();
		PCX_TaquillaServicio.Abrir(GetPlayerId());
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	protected void RpcAsk_PCX_CerrarTaquilla()
	{
		if (!Replication.IsServer())
			return;

		PCX_TaquillaServicio.CerrarPorCliente(GetPlayerId());
	}

	//------------------------------------------------------------------------------------------------
	// Servidor -> dueño
	//------------------------------------------------------------------------------------------------
	void PCX_AbrirTaquillaEnCliente(RplId almacenId)
	{
		Rpc(RpcDo_PCX_AbrirTaquilla, almacenId);
	}

	//------------------------------------------------------------------------------------------------
	void PCX_AvisoTaquilla(string texto, bool esError)
	{
		Rpc(RpcDo_PCX_AvisoTaquilla, texto, esError);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PCX_AbrirTaquilla(RplId almacenId)
	{
		PCX_TaquillaCliente.Abrir(almacenId);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PCX_AvisoTaquilla(string texto, bool esError)
	{
		if (esError)
			ARL_NativeMessageManager.ShowError(texto);
		else
			ARL_NativeMessageManager.ShowWarning(texto);
	}
}
