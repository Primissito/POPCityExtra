// POPCity Extra - Taquillas personales.
// Datos que el servidor guarda en $profile:PCX/Taquillas/<clave>.json (uno por personaje).
// Solo tipos básicos y arrays: SCR_JsonSaveContext los serializa tal cual.

//! Un objeto guardado (y lo que lleva dentro: bolsillos, cargador, accesorios...).
class PCX_TaquillaObjeto
{
	string m_sPrefab;
	int m_iAlmacen = -1;	// índice del componente de almacenamiento dentro del objeto padre
	int m_iRanura = -1;		// ranura dentro de ese almacenamiento
	int m_iMunicion = -1;	// -1 = no es un cargador
	float m_fSalud = 1;
	ref array<ref PCX_TaquillaObjeto> m_aContenido = {};
}

//! Contenido completo de la taquilla de un personaje.
class PCX_TaquillaDatos
{
	int m_iVersion = 1;
	string m_sClave;
	ref array<ref PCX_TaquillaObjeto> m_aObjetos = {};
}
