// POPCity Extra - Taquillas personales.
// Va en el mueble (el armario que se pone en el mapa). No guarda nada: solo marca que
// ese mueble es una taquilla. El contenido es del personaje y es el mismo en todas.

[ComponentEditorProps(category: "POPCity Extra/Taquillas", description: "Taquilla personal para cualquier jugador. El contenido es el mismo en todas las taquillas del mapa.")]
class PCX_TaquillaComponentClass : ScriptComponentClass
{
}

class PCX_TaquillaComponent : ScriptComponent
{
	[Attribute("{7C1B6A42E9D35F08}Prefabs/Structures/Taquillas/PCX_TaquillaAlmacen.et", UIWidgets.ResourceNamePicker, "Prefab del almacén personal que aparece al abrir la taquilla", "et")]
	protected ResourceName m_sPrefabAlmacen;

	[Attribute("0 0.9 0.6", UIWidgets.EditBox, "Posición local donde aparece el almacén personal (delante de las puertas, a la vista del jugador)")]
	protected vector m_vPosicionAlmacen;

	// Registro de taquillas del mapa (el servidor busca la más cercana al jugador).
	protected static ref array<IEntity> s_aTaquillas = {};

	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		if (s_aTaquillas.Find(owner) < 0)
			s_aTaquillas.Insert(owner);
	}

	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		s_aTaquillas.RemoveItem(owner);
		super.OnDelete(owner);
	}

	//------------------------------------------------------------------------------------------------
	ResourceName GetPrefabAlmacen()
	{
		return m_sPrefabAlmacen;
	}

	//------------------------------------------------------------------------------------------------
	vector GetPosicionAlmacenMundo()
	{
		return GetOwner().CoordToParent(m_vPosicionAlmacen);
	}

	//------------------------------------------------------------------------------------------------
	//! Taquilla más cercana a una posición dentro de un radio (null si no hay ninguna).
	static PCX_TaquillaComponent BuscarCercana(vector posicion, float radio)
	{
		PCX_TaquillaComponent mejor;
		float mejorDistancia = radio * radio;
		foreach (IEntity entidad : s_aTaquillas)
		{
			if (!entidad || entidad.IsDeleted())
				continue;

			float distancia = vector.DistanceSq(posicion, entidad.GetOrigin());
			if (distancia > mejorDistancia)
				continue;

			PCX_TaquillaComponent taquilla = PCX_TaquillaComponent.Cast(entidad.FindComponent(PCX_TaquillaComponent));
			if (!taquilla)
				continue;

			mejor = taquilla;
			mejorDistancia = distancia;
		}
		return mejor;
	}
}
