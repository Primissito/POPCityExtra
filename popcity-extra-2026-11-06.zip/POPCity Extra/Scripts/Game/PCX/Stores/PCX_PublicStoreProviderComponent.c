// POPCity Extra - Tienda abierta a todas las facciones (máquinas expendedoras).
// Mismo patrón que ARL_MechanicStoreProviderComponent de POPCity: solo cambia la facción requerida.
// El catálogo, el cobro (backend de POPCity) y la entrega al inventario los hace POPCity.
class PCX_PublicStoreProviderComponentClass : ARL_ObjectStoreProviderComponentClass
{
}

[ComponentEditorProps(category: "POPCity Extra/Item Store", description: "Tienda de POPCity abierta a civiles, policías y médicos.")]
class PCX_PublicStoreProviderComponent : ARL_ObjectStoreProviderComponent
{
	// Cadena vacía = sin facción requerida (igual que las tiendas de comida de POPCity).
	override string GetRequiredFactionKey()
	{
		return string.Empty;
	}
}
