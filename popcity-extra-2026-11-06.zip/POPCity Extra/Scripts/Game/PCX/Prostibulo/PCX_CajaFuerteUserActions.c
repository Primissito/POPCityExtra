// POPCity Extra - Atraco al prostíbulo.
// Acciones de la caja fuerte:
//  - "Forzar caja fuerte": solo la ve el atracador en la fase 2. Corre en el cliente y pide al
//    servidor que abra el minijuego (el servidor vuelve a comprobarlo todo).
//  - "Coger el botín": abrir el almacén (acción de inventario vanilla) solo con la caja abierta.

class PCX_ForzarCajaFuerteUserAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool HasLocalEffectOnlyScript()
	{
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		PCX_AtracoProstibuloComponent caja = PCX_AtracoProstibuloComponent.DesdeEntidad(GetOwner());
		if (!caja || caja.GetFase() != PCX_EFaseAtraco.CAJA)
			return false;

		PlayerController pc = GetGame().GetPlayerController();
		return pc && pc.GetPlayerId() == caja.GetAtracador() && !PCX_RuedaCombinacionDialog.EstaAbierto();
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity || pUserEntity != SCR_PlayerController.GetLocalControlledEntity())
			return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerController());
		if (rpl && pc)
		{
			PCX_RuedaCombinacionDialog.Preparar(rpl.Id());
			pc.PCX_AtracoAbrirCaja(rpl.Id());
		}
	}
}

//------------------------------------------------------------------------------------------------
// Hereda de la acción vanilla de abrir almacén (en el prefab se usa con OpenStorageAction.conf,
// igual que las cajas de contenedores de POPCity).
class PCX_CajaFuerteBotinAction : SCR_OpenStorageAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		PCX_AtracoProstibuloComponent caja = PCX_AtracoProstibuloComponent.DesdeEntidad(GetOwner());
		if (!caja || !caja.EstaAbierta())
			return false;
		return super.CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user) && super.CanBePerformedScript(user);
	}
}
