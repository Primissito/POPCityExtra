// POPCity Extra - Atraco al prostíbulo.
// RPCs del minijuego de la caja fuerte. Mismo patrón que la ganzúa de POPCity (ARL_Lockpick):
// el cliente solo envía el número que fija; la combinación se queda en el servidor.

modded class SCR_PlayerController
{
	protected float m_fPCXAtracoSiguiente;

	//------------------------------------------------------------------------------------------------
	// Cliente -> servidor
	//------------------------------------------------------------------------------------------------
	void PCX_AtracoAbrirCaja(RplId caja)
	{
		Rpc(RpcAsk_PCX_AtracoAbrirCaja, caja);
	}

	//------------------------------------------------------------------------------------------------
	void PCX_AtracoProbarNumero(RplId caja, int token, int valor)
	{
		Rpc(RpcAsk_PCX_AtracoProbarNumero, caja, token, valor);
	}

	//------------------------------------------------------------------------------------------------
	protected PCX_AtracoProstibuloComponent PCX_ResolverCaja(RplId caja)
	{
		if (!caja.IsValid())
			return null;

		Managed objeto = Replication.FindItem(caja);
		RplComponent rpl = RplComponent.Cast(objeto);
		IEntity entidad;
		if (rpl)
			entidad = rpl.GetEntity();
		else
			entidad = IEntity.Cast(objeto);
		return PCX_AtracoProstibuloComponent.DesdeEntidad(entidad);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	protected void RpcAsk_PCX_AtracoAbrirCaja(RplId caja)
	{
		if (!Replication.IsServer())
			return;

		float ahora = GetGame().GetWorld().GetWorldTime();
		if (ahora < m_fPCXAtracoSiguiente)
			return;
		m_fPCXAtracoSiguiente = ahora + 500;

		PCX_AtracoProstibuloComponent componente = PCX_ResolverCaja(caja);
		if (componente)
			componente.ServidorAbrirMinijuego(this);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	protected void RpcAsk_PCX_AtracoProbarNumero(RplId caja, int token, int valor)
	{
		if (!Replication.IsServer())
			return;

		PCX_AtracoProstibuloComponent componente = PCX_ResolverCaja(caja);
		if (componente)
			componente.ServidorProbarNumero(this, token, valor);
	}

	//------------------------------------------------------------------------------------------------
	// Servidor -> dueño
	//------------------------------------------------------------------------------------------------
	void PCX_RespuestaCaja(int token, int respuesta, int digito, int fallos, int fallosMax, int segundos, string texto)
	{
		Rpc(RpcDo_PCX_RespuestaCaja, token, respuesta, digito, fallos, fallosMax, segundos, texto);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PCX_RespuestaCaja(int token, int respuesta, int digito, int fallos, int fallosMax, int segundos, string texto)
	{
		PCX_RuedaCombinacionDialog.Recibir(token, respuesta, digito, fallos, fallosMax, segundos, texto);
	}

	//------------------------------------------------------------------------------------------------
	void PCX_AbrirBotinEnCliente(RplId caja)
	{
		Rpc(RpcDo_PCX_AbrirBotin, caja);
	}

	//------------------------------------------------------------------------------------------------
	// Abre el inventario con la caja fuerte a la vista (lo mismo que hace SCR_OpenStorageAction).
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PCX_AbrirBotin(RplId caja)
	{
		PCX_AtracoProstibuloComponent componente = PCX_ResolverCaja(caja);
		IEntity cuerpo = GetControlledEntity();
		if (!componente || !cuerpo)
			return;

		if (vector.DistanceSq(cuerpo.GetOrigin(), componente.GetOwner().GetOrigin()) > 16)
		{
			ARL_NativeMessageManager.ShowSuccess("La caja fuerte está abierta. Vuelve a ella y usa «Coger el botín».");
			return;
		}

		SCR_InventoryStorageManagerComponent inventario = SCR_InventoryStorageManagerComponent.Cast(cuerpo.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inventario)
			return;
		inventario.SetStorageToOpen(componente.GetOwner());
		inventario.OpenInventory();
	}
}
