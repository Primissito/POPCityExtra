// POPCity Extra - Atraco al prostíbulo.
// Antecedentes en el PDA de policía: usa la misma lista que los robos de gasolinera de POPCity.

modded class ARL_GasStationRobberyService
{
	//------------------------------------------------------------------------------------------------
	static void PCX_RegistrarAtraco(ARL_CharacterData personaje, string lugar, bool consumado)
	{
		if (!Replication.IsServer() || !personaje || personaje.characterId.IsEmpty())
			return;

		ARL_PolicePDARecordState registro = FindRecord(personaje.characterId);
		if (!registro)
		{
			registro = new ARL_PolicePDARecordState();
			registro.characterId = personaje.characterId;
			s_Records.Insert(registro);
		}

		registro.suspect = CharacterDisplayName(personaje);
		registro.station = lugar;
		if (consumado)
		{
			registro.offence = "Atraco a " + lugar;
			registro.bounty = registro.count * 6000;
		}
		else
		{
			registro.offence = "Intento de atraco a " + lugar;
			registro.count++;
			registro.bounty = registro.count * 2500;
		}
		registro.updatedAt = GetGame().GetWorld().GetWorldTime();
	}
}
