// POPCity Extra - Atraco al prostíbulo.
// Marca a un NPC como "encargado" de un atraco. La caja fuerte lo encuentra por el identificador,
// así no hace falta poner nombres a las entidades del mundo.

class PCX_EncargadoProstibuloComponentClass : ScriptComponentClass
{
}

[ComponentEditorProps(category: "POPCity Extra/Atracos", description: "NPC encargado al que hay que encañonar en la fase 1 del atraco.")]
class PCX_EncargadoProstibuloComponent : ScriptComponent
{
	[Attribute("prostibulo", UIWidgets.EditBox, "Identificador del atraco. Debe coincidir con el de la caja fuerte (PCX_AtracoProstibuloComponent).")]
	protected string m_sIdAtraco;

	protected static ref map<string, PCX_EncargadoProstibuloComponent> s_mEncargados = new map<string, PCX_EncargadoProstibuloComponent>();

	//------------------------------------------------------------------------------------------------
	static IEntity Buscar(string idAtraco)
	{
		PCX_EncargadoProstibuloComponent encargado;
		if (!s_mEncargados.Find(idAtraco, encargado) || !encargado)
			return null;
		return encargado.GetOwner();
	}

	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		if (!GetGame() || !GetGame().InPlayMode())
			return;

		if (s_mEncargados.Contains(m_sIdAtraco))
			Print(string.Format("[PCX_Atraco] Hay dos encargados con el id '%1'; se usa el último.", m_sIdAtraco), LogLevel.WARNING);
		s_mEncargados.Set(m_sIdAtraco, this);
	}

	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		PCX_EncargadoProstibuloComponent actual;
		if (s_mEncargados.Find(m_sIdAtraco, actual) && actual == this)
			s_mEncargados.Remove(m_sIdAtraco);
		super.OnDelete(owner);
	}
}
