// POPCity Extra - Atraco al prostíbulo.
// Minijuego de la rueda de combinación (solo cliente). Se abre igual que la ganzúa de POPCity
// (ARL_LockpickDialog): diálogo configurable vacío + nuestro layout encima.
// Controles: ← → gira de 1 en 1, ↑ ↓ de 10 en 10, rueda del ratón, botones en pantalla,
// Espacio/Intro fija el número, Esc sale (el atraco sigue: puedes volver a abrir la caja).

class PCX_RuedaDialogHost : SCR_ConfigurableDialogUi
{
	override void OnMenuFocusLost()
	{
		super.OnMenuFocusLost();
		PCX_RuedaCombinacionDialog.Cerrar();
	}
}

class PCX_RuedaCombinacionDialog : ScriptedWidgetEventHandler
{
	protected static const ResourceName RUTA_LAYOUT = "UI/layouts/PCX/PCX_RuedaCombinacion.layout";
	protected static const int DIGITOS = 3;

	protected static ref PCX_RuedaCombinacionDialog s_Instancia;
	protected static RplId s_Caja;

	protected Widget m_Root;
	protected MenuBase m_Menu;
	protected ref PCX_RuedaDialogHost m_Host;
	protected ref array<int> m_aFijados = {-1, -1, -1};
	protected int m_iToken, m_iDigito, m_iFallos, m_iFallosMax, m_iValor, m_iUltimoProbado;
	protected float m_fFin;
	protected bool m_bEsperando;

	//------------------------------------------------------------------------------------------------
	static bool EstaAbierto()
	{
		return s_Instancia != null;
	}

	//------------------------------------------------------------------------------------------------
	// La acción guarda qué caja se está usando antes de pedir al servidor que abra el minijuego.
	static void Preparar(RplId caja)
	{
		s_Caja = caja;
	}

	//------------------------------------------------------------------------------------------------
	static void Recibir(int token, int respuesta, int digito, int fallos, int fallosMax, int segundos, string texto)
	{
		if (respuesta == PCX_ERespuestaCaja.RECHAZADO)
		{
			Cerrar();
			ARL_NativeMessageManager.ShowWarning(texto);
			return;
		}

		if (respuesta == PCX_ERespuestaCaja.ABRIR)
		{
			Cerrar();
			s_Instancia = new PCX_RuedaCombinacionDialog();
			s_Instancia.Abrir(token, digito, fallos, fallosMax, segundos);
			return;
		}

		if (respuesta == PCX_ERespuestaCaja.ABIERTA)
		{
			Cerrar();
			SCR_UISoundEntity.SoundEvent(SCR_SoundEvent.TASK_SUCCEED);
			ARL_NativeMessageManager.ShowSuccess("¡Clac, clac, clac! La caja fuerte está abierta. Coge el botín.");
			return;
		}

		if (respuesta == PCX_ERespuestaCaja.BLOQUEADA)
		{
			Cerrar();
			SCR_UISoundEntity.SoundEvent(SCR_SoundEvent.TASK_FAILED);
			ARL_NativeMessageManager.ShowError("La caja fuerte se ha bloqueado. ¡Ha saltado la alarma!");
			return;
		}

		if (!s_Instancia || token != s_Instancia.m_iToken)
			return;

		s_Instancia.Actualizar(respuesta, digito, fallos, fallosMax, segundos, texto);
	}

	//------------------------------------------------------------------------------------------------
	static void Cerrar()
	{
		PCX_RuedaCombinacionDialog vieja = s_Instancia;
		s_Instancia = null;
		if (vieja)
			vieja.Liberar();
	}

	//------------------------------------------------------------------------------------------------
	protected void Abrir(int token, int digito, int fallos, int fallosMax, int segundos)
	{
		m_iToken = token;
		m_iDigito = digito;
		m_iFallos = fallos;
		m_iFallosMax = fallosMax;
		m_iValor = Math.RandomInt(0, 100);
		m_fFin = GetGame().GetWorld().GetWorldTime() + segundos * 1000;

		m_Menu = GetGame().GetMenuManager().OpenDialog(ChimeraMenuPreset.ConfigurableDialog, DialogPriority.INFORMATIVE, 0, true);
		SCR_ConfigurableDialogUiProxy proxy = SCR_ConfigurableDialogUiProxy.Cast(m_Menu);
		if (!proxy)
		{
			Cerrar();
			return;
		}

		m_Host = new PCX_RuedaDialogHost();
		proxy.Init(m_Host);
		m_Root = GetGame().GetWorkspace().CreateWidgets(RUTA_LAYOUT, m_Menu.GetRootWidget());
		if (!m_Root)
		{
			Print("[PCX_Atraco] No se encuentra el layout " + RUTA_LAYOUT, LogLevel.ERROR);
			Cerrar();
			return;
		}

		m_Root.AddHandler(this);
		array<string> nombres = {"Dial", "Menos10", "Menos1", "Mas1", "Mas10", "Fijar", "Salir"};
		foreach (string nombre : nombres)
		{
			Widget w = m_Root.FindAnyWidget(nombre);
			if (w)
				w.AddHandler(this);
		}

		GetGame().GetInputManager().AddActionListener(UIConstants.MENU_ACTION_BACK, EActionTrigger.DOWN, Cerrar);
		GetGame().GetCallqueue().CallLater(Tick, 100, true);
		EnfocarDial();
		PonerTexto("Pista", "Gira el dial y fija el primer número. Escucha el mecanismo.");
		Refrescar();
	}

	//------------------------------------------------------------------------------------------------
	protected void Liberar()
	{
		GetGame().GetCallqueue().Remove(Tick);
		GetGame().GetInputManager().RemoveActionListener(UIConstants.MENU_ACTION_BACK, EActionTrigger.DOWN, Cerrar);
		if (m_Root)
		{
			m_Root.RemoveFromHierarchy();
			m_Root = null;
		}
		if (m_Menu)
		{
			GetGame().GetMenuManager().CloseMenu(m_Menu);
			m_Menu = null;
		}
	}

	//------------------------------------------------------------------------------------------------
	protected void Actualizar(int respuesta, int digito, int fallos, int fallosMax, int segundos, string texto)
	{
		m_bEsperando = false;
		m_iFallos = fallos;
		m_iFallosMax = fallosMax;
		m_fFin = GetGame().GetWorld().GetWorldTime() + segundos * 1000;

		if (respuesta == PCX_ERespuestaCaja.ACIERTO)
		{
			if (m_iDigito >= 0 && m_iDigito < DIGITOS)
				m_aFijados[m_iDigito] = m_iUltimoProbado;
			m_iDigito = digito;
			SCR_UISoundEntity.SoundEvent(SCR_SoundEvent.CLICK);
			PonerTexto("Pista", "¡Clac! Ese era. Ahora el siguiente número.");
		}
		else if (respuesta == PCX_ERespuestaCaja.FALLO)
		{
			SCR_UISoundEntity.SoundEvent(SCR_SoundEvent.ERROR);
			PonerTexto("Pista", string.Format("%1: %2", m_iUltimoProbado, texto));
		}
		Refrescar();
	}

	//------------------------------------------------------------------------------------------------
	protected void Tick()
	{
		if (!m_Root)
			return;
		// Se cierra si el jugador muere o deja de controlar su personaje.
		IEntity cuerpo = SCR_PlayerController.GetLocalControlledEntity();
		CharacterControllerComponent control;
		if (cuerpo)
			control = CharacterControllerComponent.Cast(cuerpo.FindComponent(CharacterControllerComponent));
		if (!control || control.IsDead() || control.IsUnconscious())
		{
			Cerrar();
			return;
		}
		GetGame().GetInputManager().ActivateContext("MenuContext");
		PonerEstado();
	}

	//------------------------------------------------------------------------------------------------
	// Dibujo
	//------------------------------------------------------------------------------------------------
	protected void PonerTexto(string widget, string texto)
	{
		if (!m_Root)
			return;
		TextWidget t = TextWidget.Cast(m_Root.FindAnyWidget(widget));
		if (t)
			t.SetText(texto);
	}

	//------------------------------------------------------------------------------------------------
	protected string DosCifras(int numero)
	{
		numero = ((numero % 100) + 100) % 100;
		if (numero < 10)
			return "0" + numero.ToString();
		return numero.ToString();
	}

	//------------------------------------------------------------------------------------------------
	protected void PonerEstado()
	{
		int segundos = Math.Max(0, Math.Ceil((m_fFin - GetGame().GetWorld().GetWorldTime()) / 1000.0));
		PonerTexto("Estado", string.Format("Fallos: %1 / %2      Tiempo: %3 s", m_iFallos, m_iFallosMax, segundos));
	}

	//------------------------------------------------------------------------------------------------
	protected void Refrescar()
	{
		if (!m_Root)
			return;

		PonerTexto("DialM2", DosCifras(m_iValor - 2));
		PonerTexto("DialM1", DosCifras(m_iValor - 1));
		PonerTexto("DialValor", DosCifras(m_iValor));
		PonerTexto("DialP1", DosCifras(m_iValor + 1));
		PonerTexto("DialP2", DosCifras(m_iValor + 2));

		for (int i = 0; i < DIGITOS; i++)
		{
			string texto = "--";
			if (m_aFijados[i] >= 0)
				texto = DosCifras(m_aFijados[i]);
			else if (i == m_iDigito)
				texto = DosCifras(m_iValor);
			PonerTexto("Hueco" + i.ToString(), texto);

			Widget fondo = m_Root.FindAnyWidget("HuecoFondo" + i.ToString());
			if (!fondo)
				continue;
			if (m_aFijados[i] >= 0)
				fondo.SetColor(Color.FromRGBA(40, 120, 60, 255));
			else if (i == m_iDigito)
				fondo.SetColor(Color.FromRGBA(150, 110, 30, 255));
			else
				fondo.SetColor(Color.FromRGBA(35, 35, 40, 255));
		}

		Widget fijar = m_Root.FindAnyWidget("FijarFondo");
		if (fijar)
		{
			if (m_bEsperando)
				fijar.SetColor(Color.FromRGBA(70, 70, 70, 255));
			else
				fijar.SetColor(Color.FromRGBA(150, 30, 60, 255));
		}
		PonerEstado();
	}

	//------------------------------------------------------------------------------------------------
	// Entrada
	//------------------------------------------------------------------------------------------------
	protected void Girar(int pasos)
	{
		if (m_bEsperando || pasos == 0)
			return;
		m_iValor = ((m_iValor + pasos) % 100 + 100) % 100;
		SCR_UISoundEntity.SoundEvent(SCR_SoundEvent.FOCUS);
		Refrescar();
	}

	//------------------------------------------------------------------------------------------------
	protected void Fijar()
	{
		if (m_bEsperando)
			return;
		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc)
			return;

		m_bEsperando = true;
		m_iUltimoProbado = m_iValor;
		pc.PCX_AtracoProbarNumero(s_Caja, m_iToken, m_iValor);
		Refrescar();
	}

	//------------------------------------------------------------------------------------------------
	protected void EnfocarDial()
	{
		// En Workbench (servidor local) la respuesta del servidor llega en la misma llamada:
		// si cerró el diálogo (caja abierta o bloqueada), ya no hay widgets.
		if (!m_Root)
			return;
		Widget dial = m_Root.FindAnyWidget("Dial");
		if (dial)
			GetGame().GetWorkspace().SetFocusedWidget(dial, true);
	}

	//------------------------------------------------------------------------------------------------
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!w || !m_Root)
			return false;

		string nombre = w.GetName();
		bool usado = true;
		if (nombre == "Menos10")
			Girar(-10);
		else if (nombre == "Menos1")
			Girar(-1);
		else if (nombre == "Mas1")
			Girar(1);
		else if (nombre == "Mas10")
			Girar(10);
		else if (nombre == "Fijar")
			Fijar();
		else if (nombre == "Salir")
		{
			Cerrar();
			return true;
		}
		else
			usado = false;

		if (usado)
			EnfocarDial();
		return usado;
	}

	//------------------------------------------------------------------------------------------------
	override bool OnController(Widget w, ControlID control, int value)
	{
		if (!w || value == 0 || w.GetName() != "Dial")
			return false;

		if (control == ControlID.LEFT)
		{
			Girar(-1);
			return true;
		}
		if (control == ControlID.RIGHT)
		{
			Girar(1);
			return true;
		}
		if (control == ControlID.UP)
		{
			Girar(10);
			return true;
		}
		if (control == ControlID.DOWN)
		{
			Girar(-10);
			return true;
		}
		if (control == ControlID.SELECT)
		{
			Fijar();
			return true;
		}
		return false;
	}

	//------------------------------------------------------------------------------------------------
	override bool OnMouseWheel(Widget w, int x, int y, int wheel)
	{
		if (wheel > 0)
			Girar(1);
		else if (wheel < 0)
			Girar(-1);
		return true;
	}
}
