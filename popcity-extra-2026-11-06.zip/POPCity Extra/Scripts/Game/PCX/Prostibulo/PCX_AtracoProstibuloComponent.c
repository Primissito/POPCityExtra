// POPCity Extra - Atraco al prostíbulo.
// Componente de la caja fuerte. Toda la lógica del atraco corre en el servidor:
//   Fase 1: un jugador apunta al encargado (NPC) sin dejar de hacerlo durante X segundos.
//   Fase 2: solo ese jugador puede usar la caja fuerte (minijuego de rueda de combinación).
//           La combinación nunca sale del servidor: el cliente solo envía el número que fija.
//   Fase 3: la caja se abre con fajos de dinero negro de POPCity durante unos minutos.
// Reutiliza de POPCity: apuntado (ARL_GasStationRobberyService.IsAiming), avisos a policía,
// mensajes, antecedentes del PDA, fajos (ARL_DirtyMoney) y la pose de manos arriba (BFS_).

enum PCX_EFaseAtraco
{
	LIBRE,
	ENCARGADO,
	CAJA,
	ABIERTA
}

// Respuestas del servidor al minijuego (PCX_PlayerController_Atraco -> PCX_RuedaCombinacionDialog).
enum PCX_ERespuestaCaja
{
	ABRIR,			// abre el minijuego
	FALLO,			// número incorrecto (lleva pista)
	ACIERTO,		// número correcto, pasa al siguiente
	ABIERTA,		// los tres números correctos
	BLOQUEADA,		// demasiados fallos o se acabó el tiempo
	RECHAZADO		// no puedes usar la caja ahora (texto en el aviso)
}

class PCX_AtracoProstibuloComponentClass : ScriptComponentClass
{
}

[ComponentEditorProps(category: "POPCity Extra/Atracos", description: "Caja fuerte del atraco al prostíbulo (encargado + rueda de combinación).")]
class PCX_AtracoProstibuloComponent : ScriptComponent
{
	[Attribute("prostibulo", UIWidgets.EditBox, "Identificador del atraco. Debe coincidir con el del encargado (PCX_EncargadoProstibuloComponent).")]
	protected string m_sIdAtraco;

	[Attribute("Prostíbulo", UIWidgets.EditBox, "Nombre que ven policía y atracador en los avisos.")]
	protected string m_sNombreLugar;

	[Attribute("0", UIWidgets.EditBox, "Policías conectados necesarios para empezar (0 = sin mínimo, para pruebas).", "0 32")]
	protected int m_iMinPolicias;

	[Attribute("45", UIWidgets.EditBox, "Fase 1: segundos apuntando al encargado.", "5 600")]
	protected int m_iSegundosEncargado;

	[Attribute("150", UIWidgets.EditBox, "Fase 2: segundos para abrir la caja después de que cante el encargado.", "20 900")]
	protected int m_iSegundosCaja;

	[Attribute("6", UIWidgets.EditBox, "Fase 2: fallos permitidos en la rueda antes de que se bloquee.", "1 30")]
	protected int m_iFallosMaximos;

	[Attribute("1", UIWidgets.EditBox, "Margen de acierto de cada número (0 = exacto).", "0 5")]
	protected int m_iMargen;

	[Attribute("12000", UIWidgets.EditBox, "Botín mínimo en dinero negro.", "1 1000000")]
	protected int m_iBotinMinimo;

	[Attribute("18000", UIWidgets.EditBox, "Botín máximo en dinero negro.", "1 1000000")]
	protected int m_iBotinMaximo;

	[Attribute("300", UIWidgets.EditBox, "Segundos que la caja queda abierta. Al cerrarse se borra lo que quede dentro.", "30 3600")]
	protected int m_iSegundosAbierta;

	[Attribute("3600", UIWidgets.EditBox, "Enfriamiento tras un atraco completado (s).", "60 86400")]
	protected int m_iEnfriamiento;

	[Attribute("120", UIWidgets.EditBox, "Enfriamiento tras un atraco fallido o cancelado (s).", "0 86400")]
	protected int m_iEnfriamientoFallo;

	[Attribute("1", UIWidgets.CheckBox, "El encargado levanta las manos durante el atraco (pose de rendición de POPCity).")]
	protected bool m_bManosArriba;

	// Estado replicado: lo usan las acciones del cliente para mostrarse o no.
	[RplProp()]
	protected int m_iFase;
	[RplProp()]
	protected int m_iAtracador;

	// Solo servidor.
	protected string m_sPersonaje, m_sSesion;
	protected float m_fInicio, m_fLimite, m_fEnfriamientoHasta, m_fCierre;
	protected ref array<int> m_aCombinacion;
	protected int m_iDigito, m_iFallos, m_iToken;
	protected int m_iUltimoAviso = -1;
	protected int m_iBotin, m_iMetido, m_iValorPendiente, m_iFallosRelleno;
	protected float m_fEsperaRelleno, m_fSiguientePrueba;
	protected bool m_bRellenando, m_bSurrender, m_bCompletado;
	protected SCR_UniversalInventoryStorageComponent m_Almacen;
	protected ScriptedInventoryStorageManagerComponent m_Inventario;
	protected ref PCX_CajaFuerteRellenoCallback m_Relleno;
	protected IEntity m_FajoPendiente;
	protected ref map<int, float> m_mAvisos = new map<int, float>();

	protected static ref array<PCX_AtracoProstibuloComponent> s_aCajas = {};

	//------------------------------------------------------------------------------------------------
	// Consultas (cliente y servidor)
	//------------------------------------------------------------------------------------------------
	int GetFase() { return m_iFase; }
	int GetAtracador() { return m_iAtracador; }
	bool EstaAbierta() { return m_iFase == PCX_EFaseAtraco.ABIERTA; }

	//------------------------------------------------------------------------------------------------
	static PCX_AtracoProstibuloComponent DesdeEntidad(IEntity entidad)
	{
		if (!entidad)
			return null;
		return PCX_AtracoProstibuloComponent.Cast(entidad.FindComponent(PCX_AtracoProstibuloComponent));
	}

	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		if (!GetGame() || !GetGame().InPlayMode())
			return;

		s_aCajas.Insert(this);
		// El tick comprueba IsServer dentro: en OnPostInit la replicación aún puede no estar lista.
		GetGame().GetCallqueue().CallLater(Tick, 250, true);
	}

	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		s_aCajas.RemoveItem(this);
		if (GetGame())
			GetGame().GetCallqueue().Remove(Tick);
		if (m_Relleno)
			m_Relleno.Soltar();
		m_Relleno = null;
		super.OnDelete(owner);
	}

	//------------------------------------------------------------------------------------------------
	// Servidor
	//------------------------------------------------------------------------------------------------
	protected bool PrepararAlmacen()
	{
		if (m_Almacen && m_Inventario)
			return true;

		m_Almacen = SCR_UniversalInventoryStorageComponent.Cast(GetOwner().FindComponent(SCR_UniversalInventoryStorageComponent));
		m_Inventario = ScriptedInventoryStorageManagerComponent.Cast(GetOwner().FindComponent(ScriptedInventoryStorageManagerComponent));
		if (!m_Almacen || !m_Inventario)
		{
			Print("[PCX_Atraco] La caja fuerte no tiene SCR_UniversalInventoryStorageComponent o ScriptedInventoryStorageManagerComponent.", LogLevel.ERROR);
			return false;
		}

		// Mismo paso que las cajas de contenedores de POPCity: registrar el almacén en su gestor.
		array<BaseInventoryStorageComponent> almacenes = {};
		m_Inventario.GetStorages(almacenes);
		if (!almacenes.Contains(m_Almacen))
			m_Inventario.AddStorage(m_Almacen);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected float Ahora()
	{
		return GetGame().GetWorld().GetWorldTime();
	}

	//------------------------------------------------------------------------------------------------
	protected void Tick()
	{
		if (!GetGame() || !Replication.IsServer())
			return;

		IEntity encargado = PCX_EncargadoProstibuloComponent.Buscar(m_sIdAtraco);
		float ahora = Ahora();

		if (m_iFase == PCX_EFaseAtraco.LIBRE)
			TickLibre(encargado, ahora);
		else if (m_iFase == PCX_EFaseAtraco.ENCARGADO)
			TickEncargado(encargado, ahora);
		else if (m_iFase == PCX_EFaseAtraco.CAJA)
			TickCaja(ahora);
		else if (m_iFase == PCX_EFaseAtraco.ABIERTA)
			TickAbierta(ahora);
	}

	//------------------------------------------------------------------------------------------------
	protected bool PuedeAvisar(int jugador, float ahora)
	{
		float siguiente;
		if (m_mAvisos.Find(jugador, siguiente) && ahora < siguiente)
			return false;
		m_mAvisos.Set(jugador, ahora + 5000);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected void Mensaje(int jugador, string texto)
	{
		// ARL_RobberyMessage traduce la clave; un texto normal se muestra tal cual.
		ARL_GasStationRobberyService.Message(jugador, texto, m_sNombreLugar);
	}

	//------------------------------------------------------------------------------------------------
	protected void AvisarPolicia(array<int> jugadores)
	{
		foreach (int policia : jugadores)
		{
			if (ARL_PlayerFactionService.PlayerHasFaction(policia, ARL_PlayerFactionService.POLICE_FACTION_KEY))
				ARL_GasStationRobberyService.PoliceAlert(policia, m_sNombreLugar);
		}
	}

	//------------------------------------------------------------------------------------------------
	protected void TickLibre(IEntity encargado, float ahora)
	{
		if (!encargado)
			return;

		array<int> jugadores = {};
		GetGame().GetPlayerManager().GetPlayers(jugadores);

		foreach (int candidato : jugadores)
		{
			if (!ARL_GasStationRobberyService.IsAiming(candidato, encargado, false))
				continue;

			if (ahora < m_fEnfriamientoHasta)
			{
				if (PuedeAvisar(candidato, ahora))
				{
					int minutos = Math.Ceil((m_fEnfriamientoHasta - ahora) / 60000.0);
					string espera = string.Format("El encargado no tiene nada que darte ahora. Vuelve en %1 min.", minutos);
					if (!m_bCompletado)
						espera = string.Format("El encargado está alerta tras el último intento. Espera %1 min.", minutos);
					Mensaje(candidato, espera);
				}
				continue;
			}

			int policias = ARL_PlayerFactionService.GetPolicePlayerCount();
			if (policias < m_iMinPolicias)
			{
				if (PuedeAvisar(candidato, ahora))
					Mensaje(candidato, string.Format("No hay suficiente policía de servicio para atracar el %1 (%2/%3).", m_sNombreLugar, policias, m_iMinPolicias));
				continue;
			}

			if (ARL_GasStationRobberyService.IsRobbing(candidato) || PCX_AtracoProstibuloComponent.EstaAtracando(candidato))
				continue;

			ARL_CharacterData datos = ARL_BackendClient.GetSelectedCharacterData(candidato);
			if (!datos)
				continue;

			EmpezarAtraco(candidato, datos, encargado, jugadores, ahora);
			return;
		}
	}

	//------------------------------------------------------------------------------------------------
	static bool EstaAtracando(int jugador)
	{
		foreach (PCX_AtracoProstibuloComponent caja : s_aCajas)
		{
			if (caja && caja.m_iFase != PCX_EFaseAtraco.LIBRE && caja.m_iAtracador == jugador)
				return true;
		}
		return false;
	}

	//------------------------------------------------------------------------------------------------
	protected void EmpezarAtraco(int jugador, ARL_CharacterData datos, IEntity encargado, array<int> jugadores, float ahora)
	{
		m_iAtracador = jugador;
		m_sPersonaje = "";
		m_sSesion = "";
		if (datos)
		{
			m_sPersonaje = datos.characterId;
			m_sSesion = datos.sessionVersion;
		}
		m_fInicio = ahora;
		m_iUltimoAviso = -1;
		m_iFase = PCX_EFaseAtraco.ENCARGADO;
		Replication.BumpMe();

		if (datos)
			ARL_GasStationRobberyService.PCX_RegistrarAtraco(datos, m_sNombreLugar, false);
		AvisarPolicia(jugadores);

		if (m_bManosArriba && !m_bSurrender)
		{
			// VERIFICAR: la pose de rendición de POPCity está pensada para personajes; si el NPC
			// de servicio no la acepta, devuelve false y el atraco sigue igual (sin animación).
			m_bSurrender = BFS_HostagePoseAnchor.ToggleSurrender(encargado);
		}

		Mensaje(jugador, string.Format("¡Atraco en el %1! Sigue apuntando al encargado %2 s.", m_sNombreLugar, m_iSegundosEncargado));
		Print(string.Format("[PCX_Atraco] %1: empieza el atraco del jugador %2", m_sIdAtraco, jugador), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	protected bool AtracadorValido()
	{
		if (m_iAtracador <= 0)
			return false;

		if (!ARL_CharacterPersistenceService.IsCharacterActivated(m_iAtracador))
			return false;

		ARL_CharacterData datos = ARL_BackendClient.GetSelectedCharacterData(m_iAtracador);
		if (!datos || datos.characterId != m_sPersonaje || datos.sessionVersion != m_sSesion)
			return false;

		IEntity cuerpo = Cuerpo(m_iAtracador);
		if (!cuerpo)
			return false;

		CharacterControllerComponent vida = CharacterControllerComponent.Cast(cuerpo.FindComponent(CharacterControllerComponent));
		return vida && !vida.IsDead() && !vida.IsUnconscious();
	}

	//------------------------------------------------------------------------------------------------
	protected IEntity Cuerpo(int jugador)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(jugador);
		if (!pc)
			return null;
		return pc.GetControlledEntity();
	}

	//------------------------------------------------------------------------------------------------
	protected void TickEncargado(IEntity encargado, float ahora)
	{
		IEntity cuerpo = Cuerpo(m_iAtracador);
		bool sigue = encargado != null && cuerpo != null && AtracadorValido();
		// IsAiming de POPCity: a menos de 4 m, arma levantada, cañón hacia torso/cabeza y sin obstáculos.
		if (sigue && !ARL_GasStationRobberyService.IsAiming(m_iAtracador, encargado, false))
			sigue = false;

		if (!sigue)
		{
			Fallar("Has dejado de encañonar al encargado. El atraco se ha cancelado.");
			return;
		}

		int restantes = Math.Ceil(m_iSegundosEncargado - (ahora - m_fInicio) / 1000.0);
		if (restantes > 0)
		{
			if (m_iUltimoAviso < 0 || m_iUltimoAviso - restantes >= 5)
			{
				m_iUltimoAviso = restantes;
				Mensaje(m_iAtracador, string.Format("El encargado está nervioso... no dejes de apuntarle (%1 s).", restantes));
			}
			return;
		}

		EmpezarCaja(ahora);
	}

	//------------------------------------------------------------------------------------------------
	protected void EmpezarCaja(float ahora)
	{
		// Tres números 0-99 bien separados entre sí, como en una caja real.
		m_aCombinacion = {};
		int anterior = -100;
		for (int i = 0; i < 3; i++)
		{
			int numero = Math.RandomInt(0, 100);
			int intentos = 0;
			while (Math.AbsInt(numero - anterior) < 15 && intentos < 20)
			{
				numero = Math.RandomInt(0, 100);
				intentos++;
			}
			m_aCombinacion.Insert(numero);
			anterior = numero;
		}

		m_iDigito = 0;
		m_iFallos = 0;
		m_iToken++;
		m_fLimite = ahora + m_iSegundosCaja * 1000;
		m_iFase = PCX_EFaseAtraco.CAJA;
		Replication.BumpMe();

		Mensaje(m_iAtracador, string.Format("El encargado ha cantado: la pasta está en la caja fuerte. Tienes %1 s para abrirla.", m_iSegundosCaja));
		Print(string.Format("[PCX_Atraco] %1: fase de caja fuerte para el jugador %2", m_sIdAtraco, m_iAtracador), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	protected void TickCaja(float ahora)
	{
		IEntity cuerpo = Cuerpo(m_iAtracador);
		if (!AtracadorValido() || !cuerpo)
		{
			Fallar("El atraco se ha cancelado.");
			return;
		}

		if (vector.DistanceSq(cuerpo.GetOrigin(), GetOwner().GetOrigin()) > 625)
		{
			Fallar("Te has alejado demasiado de la caja fuerte. El atraco se ha cancelado.");
			return;
		}

		if (ahora > m_fLimite)
			Bloquear("Se acabó el tiempo: ha saltado la alarma de la caja fuerte.");
	}

	//------------------------------------------------------------------------------------------------
	// Minijuego (llamado desde PCX_PlayerController_Atraco en el servidor)
	//------------------------------------------------------------------------------------------------
	protected bool PuedeUsarCaja(int jugador, out string motivo)
	{
		motivo = "No puedes usar esta caja fuerte ahora.";
		if (m_iFase != PCX_EFaseAtraco.CAJA || jugador != m_iAtracador || !AtracadorValido())
			return false;

		IEntity cuerpo = Cuerpo(jugador);
		if (!cuerpo || vector.DistanceSq(cuerpo.GetOrigin(), GetOwner().GetOrigin()) > 9)
		{
			motivo = "Acércate más a la caja fuerte.";
			return false;
		}
		return true;
	}

	//------------------------------------------------------------------------------------------------
	int SegundosRestantes()
	{
		return Math.Max(0, Math.Ceil((m_fLimite - Ahora()) / 1000.0));
	}

	//------------------------------------------------------------------------------------------------
	void ServidorAbrirMinijuego(SCR_PlayerController pc)
	{
		if (!pc || !Replication.IsServer())
			return;

		string motivo;
		if (!PuedeUsarCaja(pc.GetPlayerId(), motivo))
		{
			pc.PCX_RespuestaCaja(0, PCX_ERespuestaCaja.RECHAZADO, 0, 0, 0, 0, motivo);
			return;
		}

		pc.PCX_RespuestaCaja(m_iToken, PCX_ERespuestaCaja.ABRIR, m_iDigito, m_iFallos, m_iFallosMaximos, SegundosRestantes(), "");
	}

	//------------------------------------------------------------------------------------------------
	void ServidorProbarNumero(SCR_PlayerController pc, int token, int valor)
	{
		if (!pc || !Replication.IsServer() || token != m_iToken)
			return;

		string motivo;
		if (!PuedeUsarCaja(pc.GetPlayerId(), motivo))
		{
			pc.PCX_RespuestaCaja(token, PCX_ERespuestaCaja.RECHAZADO, 0, 0, 0, 0, motivo);
			return;
		}

		// Anti-spam: como mucho un intento cada 0,4 s.
		float ahora = Ahora();
		if (ahora < m_fSiguientePrueba)
			return;
		m_fSiguientePrueba = ahora + 400;

		if (valor < 0 || valor > 99 || !m_aCombinacion)
			return;

		int objetivo = m_aCombinacion[m_iDigito];
		int diferencia = objetivo - valor;
		if (Math.AbsInt(diferencia) <= m_iMargen)
		{
			m_iDigito++;
			if (m_iDigito >= m_aCombinacion.Count())
			{
				pc.PCX_RespuestaCaja(token, PCX_ERespuestaCaja.ABIERTA, m_iDigito, m_iFallos, m_iFallosMaximos, 0, "");
				AbrirCaja(ahora);
				return;
			}
			pc.PCX_RespuestaCaja(token, PCX_ERespuestaCaja.ACIERTO, m_iDigito, m_iFallos, m_iFallosMaximos, SegundosRestantes(), "");
			return;
		}

		m_iFallos++;
		if (m_iFallos >= m_iFallosMaximos)
		{
			pc.PCX_RespuestaCaja(token, PCX_ERespuestaCaja.BLOQUEADA, m_iDigito, m_iFallos, m_iFallosMaximos, 0, "");
			Bloquear("La caja fuerte se ha bloqueado y ha saltado la alarma.");
			return;
		}

		pc.PCX_RespuestaCaja(token, PCX_ERespuestaCaja.FALLO, m_iDigito, m_iFallos, m_iFallosMaximos, SegundosRestantes(), Pista(diferencia));
	}

	//------------------------------------------------------------------------------------------------
	protected string Pista(int diferencia)
	{
		int distancia = Math.AbsInt(diferencia);
		string sentido = "más alto";
		if (diferencia < 0)
			sentido = "más bajo";

		if (distancia <= 5)
			return "El mecanismo casi engancha... muy cerca, " + sentido + ".";
		if (distancia <= 15)
			return "Notas algo de resistencia. Cerca, " + sentido + ".";
		if (distancia <= 35)
			return "Nada. Lejos, " + sentido + ".";
		return "Ni de lejos. Muy lejos, " + sentido + ".";
	}

	//------------------------------------------------------------------------------------------------
	// Botín
	//------------------------------------------------------------------------------------------------
	protected void AbrirCaja(float ahora)
	{
		ARL_CharacterData datos = ARL_BackendClient.GetSelectedCharacterData(m_iAtracador);
		if (datos)
			ARL_GasStationRobberyService.PCX_RegistrarAtraco(datos, m_sNombreLugar, true);

		SoltarEncargado();
		int minimo = m_iBotinMinimo;
		int maximo = m_iBotinMaximo;
		if (maximo < minimo)
			maximo = minimo;
		m_iBotin = Math.RandomInt(minimo, maximo + 1);
		m_iMetido = 0;
		m_iFallosRelleno = 0;
		m_fCierre = ahora + m_iSegundosAbierta * 1000;
		m_bRellenando = PrepararAlmacen();
		if (m_bRellenando)
			VaciarCaja(); // por si quedó algo de una prueba anterior
		m_bRellenando = m_Inventario != null;
		m_iFase = PCX_EFaseAtraco.ABIERTA;
		Replication.BumpMe();

		int minutosAbierta = Math.Ceil(m_iSegundosAbierta / 60.0);
		Mensaje(m_iAtracador, string.Format("¡Caja abierta! Coge los fajos de dinero negro: la caja se cierra en %1 min. Recuerda que debes lavarlos.", minutosAbierta));
		Print(string.Format("[PCX_Atraco] %1: caja abierta, botín %2", m_sIdAtraco, m_iBotin), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	protected int ValorFajo(IEntity objeto)
	{
		if (!objeto || !objeto.GetPrefabData())
			return 0;

		string prefab = objeto.GetPrefabData().GetPrefabName();
		if (prefab.IndexOf("/ARL_DirtyMoneyBundle.et") >= 0)
			return 10000;
		if (prefab.IndexOf("/ARL_DirtyMoneyBundle_1000.et") >= 0)
			return 1000;
		if (prefab.IndexOf("/ARL_DirtyMoneyBundle_100.et") >= 0)
			return 100;
		if (prefab.IndexOf("/ARL_DirtyMoneyBundle_10.et") >= 0)
			return 10;
		if (prefab.IndexOf("/ARL_DirtyMoneyBundle_1.et") >= 0)
			return 1;
		return 0;
	}

	//------------------------------------------------------------------------------------------------
	protected int ValorEnCaja()
	{
		if (!m_Inventario)
			return 0;

		array<IEntity> objetos = {};
		m_Inventario.GetItems(objetos);
		int total;
		foreach (IEntity objeto : objetos)
			total += ValorFajo(objeto);
		return total;
	}

	//------------------------------------------------------------------------------------------------
	// Mete los fajos de uno en uno: crea el fajo junto a la caja y lo inserta en su almacén
	// (como hace POPCity con la gasolinera). Confirma con Contains() antes de meter el siguiente.
	protected void Rellenar(float ahora)
	{
		if (!m_bRellenando || !m_Inventario || !m_Almacen)
			return;

		if (m_FajoPendiente)
		{
			if (m_Inventario.Contains(m_FajoPendiente))
			{
				m_iMetido += m_iValorPendiente;
				m_iFallosRelleno = 0;
				m_FajoPendiente = null;
			}
			else if (ahora < m_fEsperaRelleno)
			{
				return;
			}
			else
			{
				Print(string.Format("[PCX_Atraco] El fajo de %1 € no ha entrado en la caja fuerte.", m_iValorPendiente), LogLevel.WARNING);
				SCR_EntityHelper.DeleteEntityAndChildren(m_FajoPendiente);
				m_FajoPendiente = null;
				m_iFallosRelleno++;
			}
		}

		if (m_iFallosRelleno >= 3)
		{
			Print("[PCX_Atraco] Se deja de rellenar la caja fuerte tras 3 fallos seguidos.", LogLevel.ERROR);
			m_bRellenando = false;
			AvisarCajaLista();
			return;
		}

		int pendiente = m_iBotin - m_iMetido;
		if (pendiente <= 0)
		{
			m_bRellenando = false;
			Print(string.Format("[PCX_Atraco] %1: caja fuerte rellenada con %2 € (valor contado: %3).", m_sIdAtraco, m_iMetido, ValorEnCaja()), LogLevel.NORMAL);
			AvisarCajaLista();
			return;
		}

		ResourceName fajo = ARL_DirtyMoney.NextBundle(pendiente, m_iValorPendiente);
		Resource recurso = Resource.Load(fajo);
		if (!recurso || !recurso.IsValid())
		{
			Print("[PCX_Atraco] No se puede cargar el prefab del fajo: " + fajo, LogLevel.ERROR);
			m_iFallosRelleno++;
			return;
		}

		EntitySpawnParams parametros = new EntitySpawnParams();
		parametros.TransformMode = ETransformMode.WORLD;
		parametros.Transform[3] = GetOwner().GetOrigin() + Vector(0, 0.5, 0);
		IEntity nuevoFajo = GetGame().SpawnEntityPrefab(recurso, GetOwner().GetWorld(), parametros);
		if (!nuevoFajo)
		{
			m_iFallosRelleno++;
			return;
		}

		m_FajoPendiente = nuevoFajo;
		m_fEsperaRelleno = ahora + 3000;
		if (m_Relleno)
			m_Relleno.Soltar();
		m_Relleno = new PCX_CajaFuerteRellenoCallback();

		bool aceptado = m_Inventario.TryInsertItemInStorage(nuevoFajo, m_Almacen, -1, m_Relleno);
		if (!aceptado)
			aceptado = m_Inventario.TryInsertItem(nuevoFajo, EStoragePurpose.PURPOSE_ANY, m_Relleno);
		if (!aceptado)
		{
			Print(string.Format("[PCX_Atraco] La caja fuerte rechaza el fajo %1 (¿tipo de hueco o volumen del almacén?).", fajo), LogLevel.WARNING);
			m_fEsperaRelleno = ahora; // se cuenta como fallo en el siguiente tick
		}
	}

	//------------------------------------------------------------------------------------------------
	// Abre el inventario de la caja al atracador en cuanto está llena.
	protected void AvisarCajaLista()
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(m_iAtracador);
		SCR_PlayerController scr = SCR_PlayerController.Cast(pc);
		RplComponent rpl = RplComponent.Cast(GetOwner().FindComponent(RplComponent));
		if (scr && rpl)
			scr.PCX_AbrirBotinEnCliente(rpl.Id());
	}

	//------------------------------------------------------------------------------------------------
	protected void TickAbierta(float ahora)
	{
		Rellenar(ahora);
		if (ahora < m_fCierre)
			return;

		VaciarCaja();
		Terminar(m_iEnfriamiento, true);
	}

	//------------------------------------------------------------------------------------------------
	protected void VaciarCaja()
	{
		m_bRellenando = false;
		if (m_Relleno)
			m_Relleno.Soltar();
		m_Relleno = null;
		if (m_FajoPendiente)
			SCR_EntityHelper.DeleteEntityAndChildren(m_FajoPendiente);
		m_FajoPendiente = null;
		if (!m_Inventario)
			return;

		array<IEntity> objetos = {};
		m_Inventario.GetItems(objetos);
		foreach (IEntity objeto : objetos)
		{
			if (objeto)
				SCR_EntityHelper.DeleteEntityAndChildren(objeto);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Final del atraco
	//------------------------------------------------------------------------------------------------
	protected void SoltarEncargado()
	{
		if (!m_bSurrender)
			return;

		IEntity encargado = PCX_EncargadoProstibuloComponent.Buscar(m_sIdAtraco);
		if (encargado)
			BFS_HostagePoseAnchor.ReleaseSurrender(encargado);
		m_bSurrender = false;
	}

	//------------------------------------------------------------------------------------------------
	protected void Fallar(string texto)
	{
		if (m_iAtracador > 0)
			Mensaje(m_iAtracador, texto);
		Terminar(m_iEnfriamientoFallo, false);
	}

	//------------------------------------------------------------------------------------------------
	// Fallo con alarma: además avisa otra vez a la policía.
	protected void Bloquear(string texto)
	{
		array<int> jugadores = {};
		GetGame().GetPlayerManager().GetPlayers(jugadores);
		AvisarPolicia(jugadores);
		Fallar(texto);
	}

	//------------------------------------------------------------------------------------------------
	protected void Terminar(int enfriamiento, bool completado)
	{
		SoltarEncargado();
		m_bCompletado = completado;
		m_fEnfriamientoHasta = Ahora() + enfriamiento * 1000;
		m_mAvisos.Clear();
		if (m_iAtracador > 0)
			m_mAvisos.Set(m_iAtracador, Ahora() + 5000);

		m_aCombinacion = null;
		m_iToken++;
		m_iAtracador = 0;
		m_sPersonaje = "";
		m_sSesion = "";
		m_iFase = PCX_EFaseAtraco.LIBRE;
		Replication.BumpMe();
		Print(string.Format("[PCX_Atraco] %1: fin del atraco (completado %2), enfriamiento %3 s", m_sIdAtraco, completado, enfriamiento), LogLevel.NORMAL);
	}
}

//------------------------------------------------------------------------------------------------
class PCX_CajaFuerteRellenoCallback : ScriptedInventoryOperationCallback
{
	protected bool m_bTerminado;

	bool Terminado() { return m_bTerminado; }
	void Soltar() { m_bTerminado = true; }

	override void OnComplete() { m_bTerminado = true; }
	override void OnFailed() { m_bTerminado = true; }
}
