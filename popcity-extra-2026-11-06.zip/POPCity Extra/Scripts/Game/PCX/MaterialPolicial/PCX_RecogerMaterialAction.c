// POPCity Extra - Acción "Recoger" del material policial desplegado.
// Corre en el cliente (solo la ven los policías) y pide la recogida al servidor, que lo vuelve a comprobar.

class PCX_RecogerMaterialAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool HasLocalEffectOnlyScript()
	{
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		PCX_MaterialDesplegadoComponent material = PCX_MaterialDesplegadoComponent.DesdeEntidad(GetOwner());
		if (!material || !user)
			return false;

		CharacterControllerComponent controlador = CharacterControllerComponent.Cast(user.FindComponent(CharacterControllerComponent));
		if (!controlador || controlador.IsDead() || controlador.IsUnconscious())
			return false;

		return !material.EsSoloPolicia() || PCX_MaterialPolicial.EsPoliciaLocal();
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity || pUserEntity != SCR_PlayerController.GetLocalControlledEntity())
			return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerController());
		if (rpl && pc)
			pc.PCX_PedirRecogerMaterial(rpl.Id());
	}
}
