// POPCity Extra - Material policial colocable (conos, señal STOP, barrera...).
// Objeto de inventario que se coge con la mano y se coloca con la previsualización vanilla
// (SCR_ItemPlacementComponent, igual que las cargas explosivas). Cuando el servidor termina de
// colocarlo (PlacementDone), lo cambia por el prop desplegado, que tiene colisión y la acción "Recoger".
// Si lo coloca alguien que no es policía, se queda en el suelo como un objeto normal.

[EntityEditorProps(category: "GameScripted/PCX", description: "Material policial colocable")]
class PCX_MaterialColocableComponentClass : SCR_PlaceableInventoryItemComponentClass
{
}

class PCX_MaterialColocableComponent : SCR_PlaceableInventoryItemComponent
{
	[Attribute("", UIWidgets.ResourcePickerThumbnail, "Prefab que aparece al colocarlo en el suelo", "et")]
	protected ResourceName m_sPrefabDesplegado;

	[Attribute("1", UIWidgets.CheckBox, "Solo la policía puede desplegarlo")]
	protected bool m_bSoloPolicia;

	protected bool m_bDesplegando;
	protected vector m_aPCXTransform[4];

	//------------------------------------------------------------------------------------------------
	// Se llama en todas las máquinas; solo actúa el servidor.
	override protected void PlacementDone(notnull ChimeraCharacter user)
	{
		super.PlacementDone(user);

		if (!Replication.IsServer() || m_bDesplegando || m_sPrefabDesplegado.IsEmpty())
			return;

		int jugador = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(user);
		if (m_bSoloPolicia && !PCX_MaterialPolicial.EsPolicia_S(jugador))
		{
			PCX_MaterialPolicial.Aviso(jugador, "Solo la policía puede desplegar este material.", true);
			return;
		}

		// m_vMat es la posición exacta de la previsualización; si no llegó, la del objeto.
		if (m_vMat[3] != vector.Zero)
		{
			for (int i = 0; i < 4; i++)
				m_aPCXTransform[i] = m_vMat[i];
		}
		else
		{
			GetOwner().GetWorldTransform(m_aPCXTransform);
		}

		m_bDesplegando = true;
		// Pequeño retardo para que termine la RPC de colocación antes de borrar el objeto.
		GetGame().GetCallqueue().CallLater(Desplegar, 100, false);
	}

	//------------------------------------------------------------------------------------------------
	protected void Desplegar()
	{
		IEntity owner = GetOwner();
		if (!owner)
			return;

		Resource recurso = Resource.Load(m_sPrefabDesplegado);
		if (!recurso || !recurso.IsValid())
		{
			Print(string.Format("[PCX] Material policial: prefab desplegado no válido: %1", m_sPrefabDesplegado), LogLevel.ERROR);
			m_bDesplegando = false;
			return;
		}

		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		for (int i = 0; i < 4; i++)
			params.Transform[i] = m_aPCXTransform[i];

		IEntity desplegado = GetGame().SpawnEntityPrefab(recurso, owner.GetWorld(), params);
		if (!desplegado)
		{
			m_bDesplegando = false;
			return;
		}

		RplComponent.DeleteRplEntity(owner, false);
	}

	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		GetGame().GetCallqueue().Remove(Desplegar);
		super.OnDelete(owner);
	}
}
