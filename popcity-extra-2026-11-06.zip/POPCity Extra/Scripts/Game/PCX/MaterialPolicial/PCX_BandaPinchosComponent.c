// POPCity Extra - Banda de pinchos.
// Va en el prop desplegado de la banda. Solo en el servidor: cada pocos ms busca vehículos cerca y,
// si alguna rueda toca el suelo dentro de la banda, la revienta.
//  - Si el vehículo tiene hitzones de rueda (SCR_WheelHitZone), las deja a 0 de vida: estado vanilla
//    de rueda destruida (lo arregla el mecánico / cambio de rueda como cualquier pinchazo).
//  - Si no las tiene (algunos coches de mods), degrada la rueda directamente en la simulación.

[EntityEditorProps(category: "GameScripted/PCX", description: "Banda de pinchos: revienta las ruedas que pasan por encima")]
class PCX_BandaPinchosComponentClass : ScriptComponentClass
{
}

class PCX_BandaPinchosComponent : ScriptComponent
{
	protected static const vector SIN_CONTACTO = "0 -9999 0";

	[Attribute("1.7", UIWidgets.EditBox, "Media longitud de la banda (eje Z local, hacia delante del que la coloca, m)")]
	protected float m_fMediaLongitud;

	[Attribute("0.25", UIWidgets.EditBox, "Media anchura de la banda (eje X local, m), con margen")]
	protected float m_fMediaAnchura;

	[Attribute("0.6", UIWidgets.EditBox, "Altura máxima del punto de contacto de la rueda sobre la banda (m)")]
	protected float m_fAltura;

	[Attribute("50", UIWidgets.EditBox, "Cada cuántos ms se comprueba", "20 1000 10")]
	protected int m_iIntervaloMs;

	[Attribute("1", UIWidgets.EditBox, "Velocidad mínima del vehículo (m/s) para pinchar")]
	protected float m_fVelocidadMinima;

	protected ref array<IEntity> m_aVehiculos = {};

	// Última posición (local a la banda) del contacto de cada rueda, para detectar cruces aunque
	// el coche vaya tan rápido que entre dos comprobaciones salte por encima de la banda.
	protected ref map<IEntity, ref array<vector>> m_mUltimaPos = new map<IEntity, ref array<vector>>();

	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		if (!Replication.IsServer())
			return;

		GetGame().GetCallqueue().CallLater(Comprobar, m_iIntervaloMs, true);
	}

	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		GetGame().GetCallqueue().Remove(Comprobar);
		super.OnDelete(owner);
	}

	//------------------------------------------------------------------------------------------------
	protected void Comprobar()
	{
		IEntity owner = GetOwner();
		if (!owner)
			return;

		m_aVehiculos.Clear();
		float radio = m_fMediaLongitud + 4;
		owner.GetWorld().QueryEntitiesBySphere(owner.GetOrigin(), radio, AnadirVehiculo, null, EQueryEntitiesFlags.DYNAMIC);

		foreach (IEntity vehiculo : m_aVehiculos)
		{
			ComprobarVehiculo(vehiculo);
		}

		// Olvidar vehículos que ya no están cerca.
		array<IEntity> fuera = {};
		foreach (IEntity conocido, array<vector> posiciones : m_mUltimaPos)
		{
			if (!conocido || m_aVehiculos.Find(conocido) == -1)
				fuera.Insert(conocido);
		}
		foreach (IEntity olvidar : fuera)
		{
			m_mUltimaPos.Remove(olvidar);
		}
	}

	//------------------------------------------------------------------------------------------------
	protected bool AnadirVehiculo(IEntity e)
	{
		if (e && e.FindComponent(VehicleWheeledSimulation) && m_aVehiculos.Find(e) == -1)
			m_aVehiculos.Insert(e);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected void ComprobarVehiculo(IEntity vehiculo)
	{
		VehicleWheeledSimulation sim = VehicleWheeledSimulation.Cast(vehiculo.FindComponent(VehicleWheeledSimulation));
		if (!sim || !sim.IsValid())
			return;

		IEntity owner = GetOwner();
		int n = sim.WheelCount();

		array<vector> previas = m_mUltimaPos.Get(vehiculo);
		bool hayPrevias = previas && previas.Count() == n;
		array<vector> actuales = {};
		actuales.Resize(n);

		Physics fisica = vehiculo.GetPhysics();
		bool rapido = !fisica || fisica.GetVelocity().Length() >= m_fVelocidadMinima;

		for (int i = 0; i < n; i++)
		{
			// Rueda en el aire: no pincha y se corta el trayecto (no se une con la siguiente).
			if (!sim.WheelHasContact(i))
			{
				actuales[i] = SIN_CONTACTO;
				continue;
			}

			vector local = owner.CoordToLocal(sim.WheelGetContactPosition(i));
			actuales[i] = local;

			if (!rapido || local[1] < -0.3 || local[1] > m_fAltura)
				continue;

			vector desde = local;
			if (hayPrevias && previas[i] != SIN_CONTACTO)
				desde = previas[i];

			if (SegmentoTocaBanda(desde, local))
				ReventarRueda(vehiculo, sim, i);
		}

		m_mUltimaPos.Set(vehiculo, actuales);
	}

	//------------------------------------------------------------------------------------------------
	// ¿El trayecto de la rueda entre dos comprobaciones (plano XZ local) pasa por el rectángulo
	// de la banda? Recorte de segmento contra caja (Liang-Barsky).
	protected bool SegmentoTocaBanda(vector a, vector b)
	{
		float t0 = 0;
		float t1 = 1;
		float dx = b[0] - a[0];
		float dz = b[2] - a[2];

		if (!Recortar(-dx, a[0] + m_fMediaAnchura, t0, t1))
			return false;
		if (!Recortar(dx, m_fMediaAnchura - a[0], t0, t1))
			return false;
		if (!Recortar(-dz, a[2] + m_fMediaLongitud, t0, t1))
			return false;
		if (!Recortar(dz, m_fMediaLongitud - a[2], t0, t1))
			return false;

		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected bool Recortar(float p, float q, inout float t0, inout float t1)
	{
		if (p == 0)
			return q >= 0;

		float r = q / p;
		if (p < 0)
		{
			if (r > t1)
				return false;
			if (r > t0)
				t0 = r;
		}
		else
		{
			if (r < t0)
				return false;
			if (r < t1)
				t1 = r;
		}
		return true;
	}

	//------------------------------------------------------------------------------------------------
	protected void ReventarRueda(IEntity vehiculo, VehicleWheeledSimulation sim, int rueda)
	{
		SCR_WheelHitZone hz = BuscarHitZoneRueda(vehiculo, rueda);
		if (hz)
		{
			if (hz.GetDamageState() == EDamageState.DESTROYED)
				return;

			hz.SetHealth(0);
			Print(string.Format("[PCX] Banda de pinchos: rueda %1 reventada (%2)", rueda, vehiculo), LogLevel.NORMAL);
			return;
		}

		// Sin hitzone de rueda: degradamos la simulación (igual que una rueda destruida vanilla).
		float radio = sim.WheelGetRadius(rueda) * 0.8;
		if (sim.WheelGetRadiusState(rueda) <= radio + 0.001)
			return;

		sim.WheelSetRadiusState(rueda, radio);
		sim.WheelTyreSetLongitudinalFrictionState(rueda, sim.WheelTyreGetLongitudinalFriction(rueda) * 0.2);
		sim.WheelTyreSetLateralFrictionState(rueda, sim.WheelTyreGetLateralFriction(rueda) * 0.2);
		sim.WheelTyreSetRoughnessState(rueda, sim.WheelTyreGetRoughness(rueda) + 3);
		sim.WheelSetRollingDrag(rueda, 1);
		Print(string.Format("[PCX] Banda de pinchos: rueda %1 reventada sin hitzone (%2)", rueda, vehiculo), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	protected SCR_WheelHitZone BuscarHitZoneRueda(IEntity vehiculo, int rueda)
	{
		HitZoneContainerComponent contenedor = HitZoneContainerComponent.Cast(vehiculo.FindComponent(HitZoneContainerComponent));
		if (!contenedor)
			return null;

		array<HitZone> hitzones = {};
		contenedor.GetAllHitZonesInHierarchy(hitzones);
		foreach (HitZone h : hitzones)
		{
			SCR_WheelHitZone hzRueda = SCR_WheelHitZone.Cast(h);
			if (hzRueda && hzRueda.GetWheelIndex() == rueda)
				return hzRueda;
		}
		return null;
	}
}
