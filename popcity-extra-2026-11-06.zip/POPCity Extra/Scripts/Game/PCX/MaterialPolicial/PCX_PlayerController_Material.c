// POPCity Extra - Material policial. RPCs entre el cliente y el servidor.

modded class SCR_PlayerController
{
	protected int m_iPCXMaterialUltimaPeticion;

	//------------------------------------------------------------------------------------------------
	// Cliente -> servidor
	//------------------------------------------------------------------------------------------------
	void PCX_PedirRecogerMaterial(RplId materialId)
	{
		Rpc(RpcAsk_PCX_RecogerMaterial, materialId);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	protected void RpcAsk_PCX_RecogerMaterial(RplId materialId)
	{
		if (!Replication.IsServer())
			return;

		// Anti-spam: una petición cada medio segundo.
		if (m_iPCXMaterialUltimaPeticion > 0 && System.GetTickCount(m_iPCXMaterialUltimaPeticion) < 500)
			return;
		m_iPCXMaterialUltimaPeticion = System.GetTickCount();

		RplComponent rpl = RplComponent.Cast(Replication.FindItem(materialId));
		if (!rpl)
			return;

		PCX_MaterialDesplegadoComponent material = PCX_MaterialDesplegadoComponent.DesdeEntidad(rpl.GetEntity());
		if (material)
			material.Recoger_S(GetPlayerId(), GetControlledEntity());
	}

	//------------------------------------------------------------------------------------------------
	// Servidor -> dueño
	//------------------------------------------------------------------------------------------------
	void PCX_AvisoMaterial(string texto, bool esError)
	{
		Rpc(RpcDo_PCX_AvisoMaterial, texto, esError);
	}

	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PCX_AvisoMaterial(string texto, bool esError)
	{
		if (esError)
			ARL_NativeMessageManager.ShowError(texto);
		else
			ARL_NativeMessageManager.ShowWarning(texto);
	}
}
