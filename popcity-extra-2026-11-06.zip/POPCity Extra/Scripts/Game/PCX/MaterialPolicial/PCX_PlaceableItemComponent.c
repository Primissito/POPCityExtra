// POPCity Extra - Material policial.
// SCR_PlaceableItemComponent vanilla carga el modelo de previsualización (m_sPreviewObject) en una
// variable local: el Resource se libera al salir de GetPreviewVobject() y el juego crashea
// ("Usage of released BaseResourceObject" en SCR_ItemPlacementComponent.EnablePreview).
// Aquí guardamos el Resource en un miembro para que siga vivo.

[EntityEditorProps(category: "GameScripted/PCX", description: "Colocable con modelo de previsualización propio")]
class PCX_PlaceableItemComponentClass : SCR_PlaceableItemComponentClass
{
}

class PCX_PlaceableItemComponent : SCR_PlaceableItemComponent
{
	protected ref Resource m_PCXPreviewResource;

	//------------------------------------------------------------------------------------------------
	override VObject GetPreviewVobject()
	{
		SCR_PlaceableItemComponentClass data = SCR_PlaceableItemComponentClass.Cast(GetComponentData(GetOwner()));
		if (!data || data.GetPreviewObjectResource().IsEmpty())
			return GetOwner().GetVObject();

		if (!m_PCXPreviewResource)
			m_PCXPreviewResource = Resource.Load(data.GetPreviewObjectResource());

		if (!m_PCXPreviewResource || !m_PCXPreviewResource.IsValid())
			return GetOwner().GetVObject();

		BaseResourceObject objeto = m_PCXPreviewResource.GetResource();
		if (!objeto)
			return GetOwner().GetVObject();

		return objeto.ToVObject();
	}
}
