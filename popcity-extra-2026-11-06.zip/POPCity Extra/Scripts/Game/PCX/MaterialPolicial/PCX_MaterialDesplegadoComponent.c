// POPCity Extra - Material policial desplegado.
// Va en el prop que queda en el suelo. Guarda qué objeto de inventario se devuelve al recogerlo.
// La recogida la decide el servidor (Recoger_S), que comprueba distancia, facción y espacio.

[EntityEditorProps(category: "GameScripted/PCX", description: "Material policial desplegado")]
class PCX_MaterialDesplegadoComponentClass : ScriptComponentClass
{
}

class PCX_MaterialDesplegadoComponent : ScriptComponent
{
	protected static const float DISTANCIA_MAX = 4;

	[Attribute("", UIWidgets.ResourcePickerThumbnail, "Objeto de inventario que se devuelve al recogerlo", "et")]
	protected ResourceName m_sObjeto;

	[Attribute("1", UIWidgets.CheckBox, "Solo la policía puede recogerlo")]
	protected bool m_bSoloPolicia;

	protected bool m_bRecogido;

	//------------------------------------------------------------------------------------------------
	static PCX_MaterialDesplegadoComponent DesdeEntidad(IEntity entidad)
	{
		if (!entidad)
			return null;
		return PCX_MaterialDesplegadoComponent.Cast(entidad.FindComponent(PCX_MaterialDesplegadoComponent));
	}

	//------------------------------------------------------------------------------------------------
	bool EsSoloPolicia()
	{
		return m_bSoloPolicia;
	}

	//------------------------------------------------------------------------------------------------
	bool Recoger_S(int jugador, IEntity personaje)
	{
		if (!Replication.IsServer() || m_bRecogido || !personaje || m_sObjeto.IsEmpty())
			return false;

		CharacterControllerComponent controlador = CharacterControllerComponent.Cast(personaje.FindComponent(CharacterControllerComponent));
		if (!controlador || controlador.IsDead() || controlador.IsUnconscious())
			return false;

		if (vector.Distance(personaje.GetOrigin(), GetOwner().GetOrigin()) > DISTANCIA_MAX)
			return false;

		if (m_bSoloPolicia && !PCX_MaterialPolicial.EsPolicia_S(jugador))
		{
			PCX_MaterialPolicial.Aviso(jugador, "Solo la policía puede recoger este material.", true);
			return false;
		}

		SCR_InventoryStorageManagerComponent inventario = SCR_InventoryStorageManagerComponent.Cast(personaje.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inventario)
			return false;

		if (!inventario.TrySpawnPrefabToStorage(m_sObjeto))
		{
			PCX_MaterialPolicial.Aviso(jugador, "No tienes espacio en el inventario.", true);
			return false;
		}

		m_bRecogido = true;
		RplComponent.DeleteRplEntity(GetOwner(), false);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class PCX_MaterialPolicial
{
	// Modo prueba: en Workbench no hay backend de POPCity, así que nadie es policía.
	// Dentro de Workbench (define WORKBENCH) se salta la comprobación de facción para poder
	// probar la mecánica. En el servidor dedicado y en el juego normal no existe ese define.
	protected static bool s_bAvisoModoPrueba;

	//------------------------------------------------------------------------------------------------
	protected static bool ModoPrueba()
	{
#ifdef WORKBENCH
		if (!s_bAvisoModoPrueba)
		{
			s_bAvisoModoPrueba = true;
			Print("[PCX] Material policial: MODO PRUEBA de Workbench, no se comprueba la facción policía.", LogLevel.WARNING);
		}
		return true;
#else
		return false;
#endif
	}

	//------------------------------------------------------------------------------------------------
	// Servidor.
	static bool EsPolicia_S(int jugador)
	{
		if (ModoPrueba())
			return true;
		return ARL_PlayerFactionService.PlayerHasFaction(jugador, ARL_PlayerFactionService.POLICE_FACTION_KEY);
	}

	//------------------------------------------------------------------------------------------------
	// Cliente (solo para mostrar u ocultar acciones; el servidor vuelve a comprobarlo).
	static bool EsPoliciaLocal()
	{
		if (ModoPrueba())
			return true;
		return ARL_PlayerFactionService.LocalPlayerHasFaction(ARL_PlayerFactionService.POLICE_FACTION_KEY);
	}

	//------------------------------------------------------------------------------------------------
	// Servidor -> aviso en pantalla al jugador.
	static void Aviso(int jugador, string texto, bool esError)
	{
		if (jugador <= 0)
			return;

		SCR_PlayerController pc = SCR_PlayerController.Cast(GetGame().GetPlayerManager().GetPlayerController(jugador));
		if (pc)
			pc.PCX_AvisoMaterial(texto, esError);
	}
}
